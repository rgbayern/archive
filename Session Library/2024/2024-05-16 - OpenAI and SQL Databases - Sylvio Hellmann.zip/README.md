# Installation
Place your own data files (csv, pdf, ...) into the `data` directory.

# create an Open AI account

if you don`t have it.

Modify `constants.py.example` to use your own [OpenAI API key](https://platform.openai.com/account/api-keys), and rename it to `constants.py`.


# Create a Azure OpenAI service
https://portal.azure.com/#view/Microsoft_Azure_ProjectOxford/CognitiveServicesHub/~/OpenAI

* Switch into the OpenAI Portal https://oai.azure.com/portal
* export the Key under configurations
* Modify `az_constants.py.example` to use your own Azure OpenAI API key, and rename it to `az_constants.py`.
* check under Management/Models if models exist --> if not create a model based on a chat model e. g. gpt-35-turbo and deploy this model
* switch into Management/Deployments and create a new deployment for you model
