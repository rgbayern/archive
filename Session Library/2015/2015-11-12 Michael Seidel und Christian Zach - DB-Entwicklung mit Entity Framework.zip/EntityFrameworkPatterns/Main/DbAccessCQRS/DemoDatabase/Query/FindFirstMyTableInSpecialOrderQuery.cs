﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace DbAccessCQRS.DemoDatabase.Query
{
    public class FindFirstMyTableInSpecialOrderQuery : IQuery<MyTable>
    {
    }
}
