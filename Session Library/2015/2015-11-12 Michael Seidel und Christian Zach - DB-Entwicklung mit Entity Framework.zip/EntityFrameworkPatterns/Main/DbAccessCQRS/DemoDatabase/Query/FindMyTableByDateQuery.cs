﻿using System;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace DbAccessCQRS.DemoDatabase.Query
{
    /// <summary>
    /// Parameterobjekt für FindMyTableByDate.
    /// </summary>
    /// <remarks>Die Namensgebung "...Query" ist eine Konvention.</remarks>
    public class FindMyTableByDateQuery : IQuery<MyTable[]>
    {
        public FindMyTableByDateQuery(DateTime date)
        {
            Date = date;
        }

        public DateTime Date { get; set; }
    }
}
