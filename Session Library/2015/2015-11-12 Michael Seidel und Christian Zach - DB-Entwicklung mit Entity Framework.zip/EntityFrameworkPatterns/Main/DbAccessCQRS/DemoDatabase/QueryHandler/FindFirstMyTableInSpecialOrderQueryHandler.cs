﻿using System.Linq;
using DbAccessCQRS.DemoDatabase.Query;
using DbAccessCQRS.DemoDatabase.QueryParts;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace DbAccessCQRS.DemoDatabase.QueryHandler
{
    public class FindFirstMyTableInSpecialOrderQueryHandler :IQueryHandler<FindFirstMyTableInSpecialOrderQuery, MyTable>
    {
        private readonly IContextFactory _contextFactory;

        public FindFirstMyTableInSpecialOrderQueryHandler(IContextFactory contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public MyTable Handle(FindFirstMyTableInSpecialOrderQuery query)
        {
            using (var context = _contextFactory.CreateNonTrackingContext<DemoContext>())
            {
                return context.MyTable
                    .AsNoTracking()
                    .InSpecialOrder()
                    .FirstOrDefault();
            }
        }
    }
}
