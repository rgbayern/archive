﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DbAccessCQRS.DemoDatabase.Query;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace DbAccessCQRS.DemoDatabase.QueryHandler
{
    public class FindMyTableByDateQueryHandler : IQueryHandler<FindMyTableByDateQuery, MyTable[]>
    {
        private readonly IContextFactory _contextFactory;

        public FindMyTableByDateQueryHandler(IContextFactory contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public MyTable[] Handle(FindMyTableByDateQuery query)
        {
            using (var context = _contextFactory.CreateNonTrackingContext<DemoContext>())
            {
                var startOfDay = query.Date.Date;
                var startOfNextDay = startOfDay.AddDays(1);
                return context.MyTable.AsNoTracking()
                    .Where(item => startOfDay <= item.Time && item.Time < startOfNextDay)
                    .ToArray();
            }
        }
    }
}
