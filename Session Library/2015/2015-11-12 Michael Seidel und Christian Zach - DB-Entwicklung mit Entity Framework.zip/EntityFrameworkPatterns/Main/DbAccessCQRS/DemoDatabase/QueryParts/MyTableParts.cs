﻿using System.Linq;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DbAccessCQRS.DemoDatabase.QueryParts
{
    public static class MyTableParts
    {
        public static IQueryable<MyTable> InSpecialOrder(this IQueryable<MyTable> query)
        {
            return query
                .OrderBy(x => x.Number)
                .ThenBy(x => x.Name);
        }
    }
}
