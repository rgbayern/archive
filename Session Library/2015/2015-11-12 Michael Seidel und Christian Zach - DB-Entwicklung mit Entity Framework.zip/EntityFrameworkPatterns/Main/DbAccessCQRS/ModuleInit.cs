﻿using System.ComponentModel.Composition;
using DbAccessCQRS.DemoDatabase.Query;
using DbAccessCQRS.DemoDatabase.QueryHandler;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace DbAccessCQRS
{
    [Export(typeof(IModule))]
    public class ModuleInit : IModule
    {
        public void Initialize(IModuleRegistrar registrar)
        {
            registrar.RegisterAsSingleton<IQueryProcessor, QueryProcessor>();
            registrar.RegisterAsSingleton<IQueryHandler<FindMyTableByDateQuery, MyTable[]>, FindMyTableByDateQueryHandler>();
            registrar.RegisterAsSingleton<IQueryHandler<FindFirstMyTableInSpecialOrderQuery, MyTable>, FindFirstMyTableInSpecialOrderQueryHandler>();

        }
    }
}
