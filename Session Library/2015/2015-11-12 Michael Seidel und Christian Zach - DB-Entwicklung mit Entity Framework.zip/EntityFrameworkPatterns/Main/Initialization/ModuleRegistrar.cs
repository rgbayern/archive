﻿using EntityFrameworkPatterns.OperationContracts;
using SimpleInjector;

namespace Initialization
{
    internal class ModuleRegistrar : IModuleRegistrar
    {
        private readonly Container _container;

        public ModuleRegistrar(Container container)
        {
            _container = container;
        }

        public void Register<TFrom, TTo>()
            where TFrom : class
            where TTo : class, TFrom
        {
            _container.Register<TFrom, TTo>();
        }

        public void RegisterAsSingleton<TFrom, TTo>()
            where TFrom : class
            where TTo : class, TFrom
        {
            _container.Register<TFrom, TTo>(Lifestyle.Singleton);
        }
    }
}