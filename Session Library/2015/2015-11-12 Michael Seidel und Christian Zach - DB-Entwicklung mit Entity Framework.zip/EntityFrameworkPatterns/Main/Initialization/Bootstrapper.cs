﻿using SimpleInjector;

namespace Initialization
{
    public static class Bootstrapper
    {
        public static Container CreateContainer()
        {
            var container = BuildUnityContainer();
            return container;
        }

        private static Container BuildUnityContainer()
        {
            var container = new Container();
            RegisterTypes(container);
            return container;
        }

        private static void RegisterTypes(Container container)
        {
            ModuleLoader.LoadContainer(container, "./", "*.dll");
        }
    }
}