﻿using System;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabaseAccessTests
{
    internal class MyTableTestHelper
    {
        internal static MyTable CreateMyTableItem(string name, int number, DateTime time)
        {
            return new MyTable
            {
                Id = Guid.NewGuid(),
                Name = name,
                Number = number,
                Time = time
            };
        }
    }
}
