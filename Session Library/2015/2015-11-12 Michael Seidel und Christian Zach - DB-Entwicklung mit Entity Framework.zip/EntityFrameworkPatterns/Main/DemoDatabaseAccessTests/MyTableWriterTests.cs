﻿using System;
using System.Linq;
using DemoDatabase.Abstractions;
using FluentAssertions;
using Initialization;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoDatabaseAccessTests
{
    [TestClass]
    public class MyTableWriterTests
    {
        private readonly IMyTableWriter _myTableWriter;
        private readonly IMyTableReader _myTableReader;

        public MyTableWriterTests()
        {
            var container = Bootstrapper.CreateContainer();
            _myTableWriter = container.GetInstance<IMyTableWriter>();
            _myTableReader = container.GetInstance<IMyTableReader>();
        }

        [TestMethod]
        public void RemoveAllMyTableItems()
        {
            _myTableWriter.Remove(x => true);
        }

        [TestMethod]
        public void Add10NewMyTables()
        {
            var itemsToAdd = Enumerable.Range(0, 10).Select(n => MyTableTestHelper.CreateMyTableItem("Datensatz " + n, n * 2, DateTime.Now.AddMinutes(n)));
            _myTableWriter.AddMany(itemsToAdd);
        }

        [TestMethod]
        public void Add10NewMyTables2()
        {
            var itemsToAdd = Enumerable.Range(0, 10).Select(n => MyTableTestHelper.CreateMyTableItem("Datensatz " + n, n * 2, DateTime.Now.AddMinutes(n)));
            foreach (var myTable in itemsToAdd)
            {
                _myTableWriter.Add(myTable);
            }
        }

        [TestMethod]
        public void Update()
        {
            var itemToUpdate = _myTableReader.GetFirst();

            itemToUpdate.Number = 1000;

            _myTableWriter.Update1(itemToUpdate);
        }

        [TestMethod]
        public void SomeScenario()
        {
            RemoveAllMyTableItems();
            var itemsToAdd = Enumerable.Range(0, 10).Select(n => MyTableTestHelper.CreateMyTableItem("Datensatz " + n, n * 2, DateTime.Now.AddMinutes(n))).ToArray();
            _myTableWriter.AddMany(itemsToAdd);

            var someToRemove = itemsToAdd.Where(item => item.Number % 3 == 0).ToArray();
            _myTableWriter.Remove(someToRemove);

            var leftInDatabase = _myTableReader.GetAllItems();

            leftInDatabase.Count().Should().Be(itemsToAdd.Length - someToRemove.Length);

            itemsToAdd.ToList().ForEach(item => item.Number = item.Number * 15);

            _myTableWriter.AddOrUpdate(itemsToAdd);
            var itemsAfterAddOrUpdate = _myTableReader.GetAllItems();

            var expected = Enumerable.Range(0, 10).Select(n => MyTableTestHelper.CreateMyTableItem("Datensatz " + n, n * 30, DateTime.Now.AddMinutes(n))).ToArray();
            itemsAfterAddOrUpdate.ShouldAllBeEquivalentTo(expected, options => options.Excluding(x => x.Id).Excluding(x => x.Modified).Excluding(x => x.Time));
        }
    }
}
