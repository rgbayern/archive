﻿using System;
using System.Data.Entity;
using EntityFrameworkPatterns.Components.DbAccess_;
using Moq;

namespace DemoDatabaseAccessTests
{
    internal class TestContextFactory<TContext> : ContextFactory 
        where TContext : DbContext
    {
        private Mock<TContext> Context { get; }

        public TestContextFactory(Mock<TContext> context )
            : base(new ConnectionInfo())
        {
            Context = context;
        }

        protected override T CreateContextInstance<T>()
        {
            return Context.Object as T;
        }
    }
}
