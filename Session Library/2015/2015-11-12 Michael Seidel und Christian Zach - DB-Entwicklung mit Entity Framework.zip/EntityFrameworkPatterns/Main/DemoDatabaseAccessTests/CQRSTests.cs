﻿using System;
using EntityFrameworkPatterns.OperationContracts;
using FluentAssertions;
using Initialization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SimpleInjector;

namespace DemoDatabaseAccessTests
{
    [TestClass]
    public class CQRSTests
    {
        private readonly Container _container = Bootstrapper.CreateContainer();

        [TestMethod]
        public void TestMethod1()
        {
            var business = _container.GetInstance<IMyTableBusiness>();
            var result = business.UseTheQuery();

            result.Should().NotBeEmpty();

            var singleResult = business.UseTheFirstOrDefaultQuery();
        }

        [TestMethod]
        public void TestMethod2()
        {
            var business = _container.GetInstance<IMyTableBusinessAdvanced>();
            var result = business.UseTheQuery();

            result.Should().NotBeEmpty();
            foreach (var myTable in result)
            {
                Console.WriteLine(myTable.Name + " " + myTable.Number);
            }

            var singleResult = business.UseTheFirstOrDefaultQuery();
        }
    }
}
