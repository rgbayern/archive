﻿using System;
using System.Linq;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoDatabaseAccessTests
{
    /// <summary>
    /// Summary description for DataAccessTests
    /// </summary>
    [TestClass]
    public class DataAccessTests
    {
        private readonly ConnectionInfo _connectionInfo = new ConnectionInfo();

        [TestMethod]
        public void TestGet()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
                var myTables = context.MyTable.ToList();
                foreach (var myTable in myTables)
                {
                    Console.WriteLine(myTable.Name + ", " + myTable.Number);
                }
            }
        }

        [TestMethod]
        public void TestGetWithProjection()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
                var myTables = context.MyTable.ToList();
                foreach (var myTable in myTables)
                {
                    Console.WriteLine(myTable.Name + ", " + myTable.Number);
                }
            }
        }

        [TestMethod]
        public void TestGetWithFilter()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
                var myTables = context.MyTable.ToList();
                foreach (var myTable in myTables)
                {
                    Console.WriteLine(myTable.Name + ", " + myTable.Number);
                }
            }
        }

        [TestMethod]
        public void TestAdd()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
            }
        }

        [TestMethod]
        public void TestUpdate()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
            }
        }

        [TestMethod]
        public void TestRemove()
        {
            using (var context = new DemoContext(_connectionInfo.ConnectionString))
            {
            }
        }
    }
}
