﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using DemoDatabase.Abstractions;
using DemoDatabase.Writer;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.ContextHelper;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.Library.CommonExtensions;
using FluentAssertions;
using Initialization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace DemoDatabaseAccessTests
{
    [TestClass]
    public class DemoDatabaseTests
    {
        /// <summary>
        /// Beispieltest: Schreiben in einen leeren, simulierten Context
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            // Der Mock-Context wird in der ContextFactory und diese im Unity-Container eingebunden.
            var mockContext = EfMoqTools.CreateMockedDbContext<DemoContext>();
            var factory = new TestContextFactory<DemoContext>(mockContext);

            // Den Writer auf den Mock-Context zugreifen lassen (über die Factory).
            var instance = new MyTableWriter(factory);
            instance.Add(MyTableTestHelper.CreateMyTableItem("Item", 4724, DateTime.Today));
            instance.Add(MyTableTestHelper.CreateMyTableItem("Hans", 8192, DateTime.Today));

            // Werte verifizieren
            var myTables = (List<MyTable>)mockContext.Tables["MyTable"];
            Assert.AreEqual(2, myTables.Count);

            // Mock-Aufrufe verifizieren
            mockContext.Verify(x => x.SaveChanges(), Times.Exactly(2));
        }

        /// <summary>
        /// Beispieltest: Lesen aus einem simulierten Context, der Testdaten enthält.
        /// </summary>
        [TestMethod]
        public void TestMethod2()
        {
            var mockContext = EfMoqTools.CreateMockedDbContext<DemoContext>();

            // Jede Tabelle im Kontext kann wie eine Liste befüllt werden.
            var myTables = (List<MyTable>)mockContext.Tables["MyTable"];
            var item = MyTableTestHelper.CreateMyTableItem("Wurst", 4724, DateTime.Today);
            myTables.Add(item);

            // Der Mock-Context wird in der ContextFactory und diese im Unity-Container eingebunden.
            var factory = new TestContextFactory<DemoContext>(mockContext);
            var container = Bootstrapper.CreateContainer();
            container.Options.AllowOverridingRegistrations = true;
            container.RegisterSingleton<IContextFactory>(factory);
            var instance = container.GetInstance<IMyTableReader>();

            // Der Test wird durchgeführt. 
            var allItems = instance.GetAllItems();
            Assert.AreEqual(allItems.Single(), item);
        }

        /// <summary>
        /// Beispieltest: Integrationstest 
        /// </summary>
        [TestMethod]
        public void TestMethod3()
        {
            // Keine Mocks notwendig
            var container = Bootstrapper.CreateContainer();
            var writer = container.GetInstance<IMyTableWriter>();
            var reader = container.GetInstance<IMyTableReader>();

            var before = reader.GetAllItems().ToList();

            // Der eigentliche Test wird in ein TransactionScope gelegt.
            using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew))
            {
                var itemToAdd = MyTableTestHelper.CreateMyTableItem("TransactionTest", 4724, DateTime.Today);
                // Unabhängig vom Context (z.B. in Add) wird der gesamte Test in einer Transaction ausgeführt.
                writer.Add(itemToAdd);

                // Lesende Zugriffe können separat mit eigener Context-Instanz ausgeführt und Daten verifiziert werden.
                var after = reader.GetAllItems().ToList();
                after.Count.Should().Be(before.Count + 1);

                var expected = new[] { new CheckedValues("TransactionTest", 4724, DateTime.Today) };
                after.LeftExcludingJoin(before, x => x.Id, y => y.Id, (x, y) => x).Select(ToCheckedValues).ShouldAllBeEquivalentTo(expected);

                // Ein Commit fehlt bewusst, so dass 
                // mit dem Dispose ein Rollback stattfindet 
                // und so der Test keine Spuren hinterlässt.
            }

            var countAfterTransaction = reader.GetAllItems().Count();
            countAfterTransaction.Should().Be(before.Count);
        }

        private CheckedValues ToCheckedValues(MyTable myTable)
        {
            return new CheckedValues(myTable.Name, myTable.Number, myTable.Time);
        }

        private class CheckedValues
        {
            public CheckedValues(string name, int number, DateTime dateTime)
            {
                Name = name;
                Number = number;
                DateTime = dateTime;
            }

            public string Name { get; set; }
            public int Number { get; set; }
            public DateTime DateTime { get; set; }
        }
    }
}
