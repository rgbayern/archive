﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.Library.CommonClasses
{
    /// <summary>
    /// Parameter für die WhereIn Methode von IQueryable
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class WhereInParam<T>
    {
        /// <summary>
        /// Gets or sets the key items.
        /// </summary>
        /// <value>
        /// The key items.
        /// </value>
        [DataMember(Order = 1)]
        public IEnumerable<T> KeyItems { get; set; }
        /// <summary>
        /// Gets or sets the key property expressions.
        /// </summary>
        /// <value>
        /// The key property expressions.
        /// </value>
        [DataMember(Order = 2)]
        public Expression<Func<T, object>>[] KeyPropertyExpressions { get; set; }
    }
}