// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Sales
{
    // PersonCreditCard
    internal partial class Sales_PersonCreditCardMapping : EntityTypeConfiguration<Sales_PersonCreditCard>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_PersonCreditCardMapping(string schema = "Sales")
        {
            ToTable(schema + ".PersonCreditCard");
            HasKey(x => new { x.BusinessEntityId, x.CreditCardId });

            Property(x => x.BusinessEntityId).HasColumnName("BusinessEntityID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.CreditCardId).HasColumnName("CreditCardID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();

            // Foreign keys
            HasRequired(a => a.Person_Person).WithMany(b => b.Sales_PersonCreditCard).HasForeignKey(c => c.BusinessEntityId); // FK_PersonCreditCard_Person_BusinessEntityID
            HasRequired(a => a.Sales_CreditCard).WithMany(b => b.Sales_PersonCreditCard).HasForeignKey(c => c.CreditCardId); // FK_PersonCreditCard_CreditCard_CreditCardID
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
