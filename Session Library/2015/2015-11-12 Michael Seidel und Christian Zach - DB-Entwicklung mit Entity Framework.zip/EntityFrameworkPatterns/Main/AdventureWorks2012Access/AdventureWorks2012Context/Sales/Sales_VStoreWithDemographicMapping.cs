// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Sales
{
    // vStoreWithDemographics
    internal partial class Sales_VStoreWithDemographicMapping : EntityTypeConfiguration<Sales_VStoreWithDemographic>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_VStoreWithDemographicMapping(string schema = "Sales")
        {
            ToTable(schema + ".vStoreWithDemographics");
            HasKey(x => new { x.BusinessEntityId, x.Name });

            Property(x => x.BusinessEntityId).HasColumnName("BusinessEntityID").IsRequired();
            Property(x => x.Name).HasColumnName("Name").IsRequired().HasMaxLength(50);
            Property(x => x.AnnualSales).HasColumnName("AnnualSales").IsOptional().HasPrecision(19,4);
            Property(x => x.AnnualRevenue).HasColumnName("AnnualRevenue").IsOptional().HasPrecision(19,4);
            Property(x => x.BankName).HasColumnName("BankName").IsOptional().HasMaxLength(50);
            Property(x => x.BusinessType).HasColumnName("BusinessType").IsOptional().HasMaxLength(5);
            Property(x => x.YearOpened).HasColumnName("YearOpened").IsOptional();
            Property(x => x.Specialty).HasColumnName("Specialty").IsOptional().HasMaxLength(50);
            Property(x => x.SquareFeet).HasColumnName("SquareFeet").IsOptional();
            Property(x => x.Brands).HasColumnName("Brands").IsOptional().HasMaxLength(30);
            Property(x => x.Internet).HasColumnName("Internet").IsOptional().HasMaxLength(30);
            Property(x => x.NumberEmployees).HasColumnName("NumberEmployees").IsOptional();
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
