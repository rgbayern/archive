// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Sales
{
    // vSalesPersonSalesByFiscalYears
    internal partial class Sales_VSalesPersonSalesByFiscalYearMapping : EntityTypeConfiguration<Sales_VSalesPersonSalesByFiscalYear>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_VSalesPersonSalesByFiscalYearMapping(string schema = "Sales")
        {
            ToTable(schema + ".vSalesPersonSalesByFiscalYears");
            HasKey(x => new { x.JobTitle, x.SalesTerritory });

            Property(x => x.SalesPersonId).HasColumnName("SalesPersonID").IsOptional();
            Property(x => x.FullName).HasColumnName("FullName").IsOptional().HasMaxLength(152);
            Property(x => x.JobTitle).HasColumnName("JobTitle").IsRequired().HasMaxLength(50);
            Property(x => x.SalesTerritory).HasColumnName("SalesTerritory").IsRequired().HasMaxLength(50);
            Property(x => x.C2002).HasColumnName("2002").IsOptional().HasPrecision(19,4);
            Property(x => x.C2003).HasColumnName("2003").IsOptional().HasPrecision(19,4);
            Property(x => x.C2004).HasColumnName("2004").IsOptional().HasPrecision(19,4);
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
