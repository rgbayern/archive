// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Person
{
    // BusinessEntityAddress
    internal partial class Person_BusinessEntityAddressMapping : EntityTypeConfiguration<Person_BusinessEntityAddress>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Person_BusinessEntityAddressMapping(string schema = "Person")
        {
            ToTable(schema + ".BusinessEntityAddress");
            HasKey(x => new { x.BusinessEntityId, x.AddressId, x.AddressTypeId });

            Property(x => x.BusinessEntityId).HasColumnName("BusinessEntityID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.AddressId).HasColumnName("AddressID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.AddressTypeId).HasColumnName("AddressTypeID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.Rowguid).HasColumnName("rowguid").IsRequired();
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();

            // Foreign keys
            HasRequired(a => a.Person_BusinessEntity).WithMany(b => b.Person_BusinessEntityAddress).HasForeignKey(c => c.BusinessEntityId); // FK_BusinessEntityAddress_BusinessEntity_BusinessEntityID
            HasRequired(a => a.Person_Address).WithMany(b => b.Person_BusinessEntityAddress).HasForeignKey(c => c.AddressId); // FK_BusinessEntityAddress_Address_AddressID
            HasRequired(a => a.Person_AddressType).WithMany(b => b.Person_BusinessEntityAddress).HasForeignKey(c => c.AddressTypeId); // FK_BusinessEntityAddress_AddressType_AddressTypeID
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
