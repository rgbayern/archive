// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Person
{
    // CountryRegion
    internal partial class Person_CountryRegionMapping : EntityTypeConfiguration<Person_CountryRegion>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Person_CountryRegionMapping(string schema = "Person")
        {
            ToTable(schema + ".CountryRegion");
            HasKey(x => x.CountryRegionCode);

            Property(x => x.CountryRegionCode).HasColumnName("CountryRegionCode").IsRequired().HasMaxLength(3).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.Name).HasColumnName("Name").IsRequired().HasMaxLength(50);
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
