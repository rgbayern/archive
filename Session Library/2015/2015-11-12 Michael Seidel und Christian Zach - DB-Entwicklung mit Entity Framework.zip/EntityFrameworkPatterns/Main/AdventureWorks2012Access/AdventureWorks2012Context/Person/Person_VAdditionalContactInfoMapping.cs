// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Person
{
    // vAdditionalContactInfo
    internal partial class Person_VAdditionalContactInfoMapping : EntityTypeConfiguration<Person_VAdditionalContactInfo>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Person_VAdditionalContactInfoMapping(string schema = "Person")
        {
            ToTable(schema + ".vAdditionalContactInfo");
            HasKey(x => new { x.BusinessEntityId, x.FirstName, x.LastName, x.Rowguid, x.ModifiedDate });

            Property(x => x.BusinessEntityId).HasColumnName("BusinessEntityID").IsRequired();
            Property(x => x.FirstName).HasColumnName("FirstName").IsRequired().HasMaxLength(50);
            Property(x => x.MiddleName).HasColumnName("MiddleName").IsOptional().HasMaxLength(50);
            Property(x => x.LastName).HasColumnName("LastName").IsRequired().HasMaxLength(50);
            Property(x => x.TelephoneNumber).HasColumnName("TelephoneNumber").IsOptional().HasMaxLength(50);
            Property(x => x.TelephoneSpecialInstructions).HasColumnName("TelephoneSpecialInstructions").IsOptional();
            Property(x => x.Street).HasColumnName("Street").IsOptional().HasMaxLength(50);
            Property(x => x.City).HasColumnName("City").IsOptional().HasMaxLength(50);
            Property(x => x.StateProvince).HasColumnName("StateProvince").IsOptional().HasMaxLength(50);
            Property(x => x.PostalCode).HasColumnName("PostalCode").IsOptional().HasMaxLength(50);
            Property(x => x.CountryRegion).HasColumnName("CountryRegion").IsOptional().HasMaxLength(50);
            Property(x => x.HomeAddressSpecialInstructions).HasColumnName("HomeAddressSpecialInstructions").IsOptional();
            Property(x => x.EMailAddress).HasColumnName("EMailAddress").IsOptional().HasMaxLength(128);
            Property(x => x.EMailSpecialInstructions).HasColumnName("EMailSpecialInstructions").IsOptional();
            Property(x => x.EMailTelephoneNumber).HasColumnName("EMailTelephoneNumber").IsOptional().HasMaxLength(50);
            Property(x => x.Rowguid).HasColumnName("rowguid").IsRequired();
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
