// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Data.Entity;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Purchasing;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace AdventureWorks2012Access.AdventureWorks2012Context
{
    [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
    public class FakeAdventureWorks2012Context : DbContext, IAdventureWorks2012Context
    {
        public DbSet<AwBuildVersion> AwBuildVersions { get; set; }
        public DbSet<DatabaseLog> DatabaseLogs { get; set; }
        public DbSet<ErrorLog> ErrorLogs { get; set; }
        public DbSet<HumanResources_Department> HumanResources_Department { get; set; }
        public DbSet<HumanResources_Employee> HumanResources_Employee { get; set; }
        public DbSet<HumanResources_EmployeeDepartmentHistory> HumanResources_EmployeeDepartmentHistory { get; set; }
        public DbSet<HumanResources_EmployeePayHistory> HumanResources_EmployeePayHistory { get; set; }
        public DbSet<HumanResources_JobCandidate> HumanResources_JobCandidate { get; set; }
        public DbSet<HumanResources_Shift> HumanResources_Shift { get; set; }
        public DbSet<HumanResources_VEmployee> HumanResources_VEmployee { get; set; }
        public DbSet<HumanResources_VEmployeeDepartment> HumanResources_VEmployeeDepartment { get; set; }
        public DbSet<HumanResources_VEmployeeDepartmentHistory> HumanResources_VEmployeeDepartmentHistory { get; set; }
        public DbSet<HumanResources_VJobCandidate> HumanResources_VJobCandidate { get; set; }
        public DbSet<HumanResources_VJobCandidateEducation> HumanResources_VJobCandidateEducation { get; set; }
        public DbSet<HumanResources_VJobCandidateEmployment> HumanResources_VJobCandidateEmployment { get; set; }
        public DbSet<Person_Address> Person_Address { get; set; }
        public DbSet<Person_AddressType> Person_AddressType { get; set; }
        public DbSet<Person_BusinessEntity> Person_BusinessEntity { get; set; }
        public DbSet<Person_BusinessEntityAddress> Person_BusinessEntityAddress { get; set; }
        public DbSet<Person_BusinessEntityContact> Person_BusinessEntityContact { get; set; }
        public DbSet<Person_ContactType> Person_ContactType { get; set; }
        public DbSet<Person_CountryRegion> Person_CountryRegion { get; set; }
        public DbSet<Person_EmailAddress> Person_EmailAddress { get; set; }
        public DbSet<Person_Password> Person_Password { get; set; }
        public DbSet<Person_Person> Person_Person { get; set; }
        public DbSet<Person_PersonPhone> Person_PersonPhone { get; set; }
        public DbSet<Person_PhoneNumberType> Person_PhoneNumberType { get; set; }
        public DbSet<Person_StateProvince> Person_StateProvince { get; set; }
        public DbSet<Person_VAdditionalContactInfo> Person_VAdditionalContactInfo { get; set; }
        public DbSet<Person_VStateProvinceCountryRegion> Person_VStateProvinceCountryRegion { get; set; }
        public DbSet<Production_BillOfMaterial> Production_BillOfMaterial { get; set; }
        public DbSet<Production_Culture> Production_Culture { get; set; }
        public DbSet<Production_Document> Production_Document { get; set; }
        public DbSet<Production_Illustration> Production_Illustration { get; set; }
        public DbSet<Production_Location> Production_Location { get; set; }
        public DbSet<Production_Product> Production_Product { get; set; }
        public DbSet<Production_ProductCategory> Production_ProductCategory { get; set; }
        public DbSet<Production_ProductCostHistory> Production_ProductCostHistory { get; set; }
        public DbSet<Production_ProductDescription> Production_ProductDescription { get; set; }
        public DbSet<Production_ProductDocument> Production_ProductDocument { get; set; }
        public DbSet<Production_ProductInventory> Production_ProductInventory { get; set; }
        public DbSet<Production_ProductListPriceHistory> Production_ProductListPriceHistory { get; set; }
        public DbSet<Production_ProductModel> Production_ProductModel { get; set; }
        public DbSet<Production_ProductModelIllustration> Production_ProductModelIllustration { get; set; }
        public DbSet<Production_ProductModelProductDescriptionCulture> Production_ProductModelProductDescriptionCulture { get; set; }
        public DbSet<Production_ProductPhoto> Production_ProductPhoto { get; set; }
        public DbSet<Production_ProductProductPhoto> Production_ProductProductPhoto { get; set; }
        public DbSet<Production_ProductReview> Production_ProductReview { get; set; }
        public DbSet<Production_ProductSubcategory> Production_ProductSubcategory { get; set; }
        public DbSet<Production_ScrapReason> Production_ScrapReason { get; set; }
        public DbSet<Production_TransactionHistory> Production_TransactionHistory { get; set; }
        public DbSet<Production_TransactionHistoryArchive> Production_TransactionHistoryArchive { get; set; }
        public DbSet<Production_UnitMeasure> Production_UnitMeasure { get; set; }
        public DbSet<Production_VProductAndDescription> Production_VProductAndDescription { get; set; }
        public DbSet<Production_VProductModelCatalogDescription> Production_VProductModelCatalogDescription { get; set; }
        public DbSet<Production_VProductModelInstruction> Production_VProductModelInstruction { get; set; }
        public DbSet<Production_WorkOrder> Production_WorkOrder { get; set; }
        public DbSet<Production_WorkOrderRouting> Production_WorkOrderRouting { get; set; }
        public DbSet<Purchasing_ProductVendor> Purchasing_ProductVendor { get; set; }
        public DbSet<Purchasing_PurchaseOrderDetail> Purchasing_PurchaseOrderDetail { get; set; }
        public DbSet<Purchasing_PurchaseOrderHeader> Purchasing_PurchaseOrderHeader { get; set; }
        public DbSet<Purchasing_ShipMethod> Purchasing_ShipMethod { get; set; }
        public DbSet<Purchasing_Vendor> Purchasing_Vendor { get; set; }
        public DbSet<Purchasing_VVendorWithAddress> Purchasing_VVendorWithAddress { get; set; }
        public DbSet<Purchasing_VVendorWithContact> Purchasing_VVendorWithContact { get; set; }
        public DbSet<Sales_CountryRegionCurrency> Sales_CountryRegionCurrency { get; set; }
        public DbSet<Sales_CreditCard> Sales_CreditCard { get; set; }
        public DbSet<Sales_Currency> Sales_Currency { get; set; }
        public DbSet<Sales_CurrencyRate> Sales_CurrencyRate { get; set; }
        public DbSet<Sales_Customer> Sales_Customer { get; set; }
        public DbSet<Sales_PersonCreditCard> Sales_PersonCreditCard { get; set; }
        public DbSet<Sales_SalesOrderDetail> Sales_SalesOrderDetail { get; set; }
        public DbSet<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; }
        public DbSet<Sales_SalesOrderHeaderSalesReason> Sales_SalesOrderHeaderSalesReason { get; set; }
        public DbSet<Sales_SalesPerson> Sales_SalesPerson { get; set; }
        public DbSet<Sales_SalesPersonQuotaHistory> Sales_SalesPersonQuotaHistory { get; set; }
        public DbSet<Sales_SalesReason> Sales_SalesReason { get; set; }
        public DbSet<Sales_SalesTaxRate> Sales_SalesTaxRate { get; set; }
        public DbSet<Sales_SalesTerritory> Sales_SalesTerritory { get; set; }
        public DbSet<Sales_SalesTerritoryHistory> Sales_SalesTerritoryHistory { get; set; }
        public DbSet<Sales_ShoppingCartItem> Sales_ShoppingCartItem { get; set; }
        public DbSet<Sales_SpecialOffer> Sales_SpecialOffer { get; set; }
        public DbSet<Sales_SpecialOfferProduct> Sales_SpecialOfferProduct { get; set; }
        public DbSet<Sales_Store> Sales_Store { get; set; }
        public DbSet<Sales_VIndividualCustomer> Sales_VIndividualCustomer { get; set; }
        public DbSet<Sales_VPersonDemographic> Sales_VPersonDemographic { get; set; }
        public DbSet<Sales_VSalesPerson> Sales_VSalesPerson { get; set; }
        public DbSet<Sales_VSalesPersonSalesByFiscalYear> Sales_VSalesPersonSalesByFiscalYear { get; set; }
        public DbSet<Sales_VStoreWithAddress> Sales_VStoreWithAddress { get; set; }
        public DbSet<Sales_VStoreWithContact> Sales_VStoreWithContact { get; set; }
        public DbSet<Sales_VStoreWithDemographic> Sales_VStoreWithDemographic { get; set; }

        public FakeAdventureWorks2012Context()
        {
            AwBuildVersions = new FakeDbSet<AwBuildVersion>();
            DatabaseLogs = new FakeDbSet<DatabaseLog>();
            ErrorLogs = new FakeDbSet<ErrorLog>();
            HumanResources_Department = new FakeDbSet<HumanResources_Department>();
            HumanResources_Employee = new FakeDbSet<HumanResources_Employee>();
            HumanResources_EmployeeDepartmentHistory = new FakeDbSet<HumanResources_EmployeeDepartmentHistory>();
            HumanResources_EmployeePayHistory = new FakeDbSet<HumanResources_EmployeePayHistory>();
            HumanResources_JobCandidate = new FakeDbSet<HumanResources_JobCandidate>();
            HumanResources_Shift = new FakeDbSet<HumanResources_Shift>();
            HumanResources_VEmployee = new FakeDbSet<HumanResources_VEmployee>();
            HumanResources_VEmployeeDepartment = new FakeDbSet<HumanResources_VEmployeeDepartment>();
            HumanResources_VEmployeeDepartmentHistory = new FakeDbSet<HumanResources_VEmployeeDepartmentHistory>();
            HumanResources_VJobCandidate = new FakeDbSet<HumanResources_VJobCandidate>();
            HumanResources_VJobCandidateEducation = new FakeDbSet<HumanResources_VJobCandidateEducation>();
            HumanResources_VJobCandidateEmployment = new FakeDbSet<HumanResources_VJobCandidateEmployment>();
            Person_Address = new FakeDbSet<Person_Address>();
            Person_AddressType = new FakeDbSet<Person_AddressType>();
            Person_BusinessEntity = new FakeDbSet<Person_BusinessEntity>();
            Person_BusinessEntityAddress = new FakeDbSet<Person_BusinessEntityAddress>();
            Person_BusinessEntityContact = new FakeDbSet<Person_BusinessEntityContact>();
            Person_ContactType = new FakeDbSet<Person_ContactType>();
            Person_CountryRegion = new FakeDbSet<Person_CountryRegion>();
            Person_EmailAddress = new FakeDbSet<Person_EmailAddress>();
            Person_Password = new FakeDbSet<Person_Password>();
            Person_Person = new FakeDbSet<Person_Person>();
            Person_PersonPhone = new FakeDbSet<Person_PersonPhone>();
            Person_PhoneNumberType = new FakeDbSet<Person_PhoneNumberType>();
            Person_StateProvince = new FakeDbSet<Person_StateProvince>();
            Person_VAdditionalContactInfo = new FakeDbSet<Person_VAdditionalContactInfo>();
            Person_VStateProvinceCountryRegion = new FakeDbSet<Person_VStateProvinceCountryRegion>();
            Production_BillOfMaterial = new FakeDbSet<Production_BillOfMaterial>();
            Production_Culture = new FakeDbSet<Production_Culture>();
            Production_Document = new FakeDbSet<Production_Document>();
            Production_Illustration = new FakeDbSet<Production_Illustration>();
            Production_Location = new FakeDbSet<Production_Location>();
            Production_Product = new FakeDbSet<Production_Product>();
            Production_ProductCategory = new FakeDbSet<Production_ProductCategory>();
            Production_ProductCostHistory = new FakeDbSet<Production_ProductCostHistory>();
            Production_ProductDescription = new FakeDbSet<Production_ProductDescription>();
            Production_ProductDocument = new FakeDbSet<Production_ProductDocument>();
            Production_ProductInventory = new FakeDbSet<Production_ProductInventory>();
            Production_ProductListPriceHistory = new FakeDbSet<Production_ProductListPriceHistory>();
            Production_ProductModel = new FakeDbSet<Production_ProductModel>();
            Production_ProductModelIllustration = new FakeDbSet<Production_ProductModelIllustration>();
            Production_ProductModelProductDescriptionCulture = new FakeDbSet<Production_ProductModelProductDescriptionCulture>();
            Production_ProductPhoto = new FakeDbSet<Production_ProductPhoto>();
            Production_ProductProductPhoto = new FakeDbSet<Production_ProductProductPhoto>();
            Production_ProductReview = new FakeDbSet<Production_ProductReview>();
            Production_ProductSubcategory = new FakeDbSet<Production_ProductSubcategory>();
            Production_ScrapReason = new FakeDbSet<Production_ScrapReason>();
            Production_TransactionHistory = new FakeDbSet<Production_TransactionHistory>();
            Production_TransactionHistoryArchive = new FakeDbSet<Production_TransactionHistoryArchive>();
            Production_UnitMeasure = new FakeDbSet<Production_UnitMeasure>();
            Production_VProductAndDescription = new FakeDbSet<Production_VProductAndDescription>();
            Production_VProductModelCatalogDescription = new FakeDbSet<Production_VProductModelCatalogDescription>();
            Production_VProductModelInstruction = new FakeDbSet<Production_VProductModelInstruction>();
            Production_WorkOrder = new FakeDbSet<Production_WorkOrder>();
            Production_WorkOrderRouting = new FakeDbSet<Production_WorkOrderRouting>();
            Purchasing_ProductVendor = new FakeDbSet<Purchasing_ProductVendor>();
            Purchasing_PurchaseOrderDetail = new FakeDbSet<Purchasing_PurchaseOrderDetail>();
            Purchasing_PurchaseOrderHeader = new FakeDbSet<Purchasing_PurchaseOrderHeader>();
            Purchasing_ShipMethod = new FakeDbSet<Purchasing_ShipMethod>();
            Purchasing_Vendor = new FakeDbSet<Purchasing_Vendor>();
            Purchasing_VVendorWithAddress = new FakeDbSet<Purchasing_VVendorWithAddress>();
            Purchasing_VVendorWithContact = new FakeDbSet<Purchasing_VVendorWithContact>();
            Sales_CountryRegionCurrency = new FakeDbSet<Sales_CountryRegionCurrency>();
            Sales_CreditCard = new FakeDbSet<Sales_CreditCard>();
            Sales_Currency = new FakeDbSet<Sales_Currency>();
            Sales_CurrencyRate = new FakeDbSet<Sales_CurrencyRate>();
            Sales_Customer = new FakeDbSet<Sales_Customer>();
            Sales_PersonCreditCard = new FakeDbSet<Sales_PersonCreditCard>();
            Sales_SalesOrderDetail = new FakeDbSet<Sales_SalesOrderDetail>();
            Sales_SalesOrderHeader = new FakeDbSet<Sales_SalesOrderHeader>();
            Sales_SalesOrderHeaderSalesReason = new FakeDbSet<Sales_SalesOrderHeaderSalesReason>();
            Sales_SalesPerson = new FakeDbSet<Sales_SalesPerson>();
            Sales_SalesPersonQuotaHistory = new FakeDbSet<Sales_SalesPersonQuotaHistory>();
            Sales_SalesReason = new FakeDbSet<Sales_SalesReason>();
            Sales_SalesTaxRate = new FakeDbSet<Sales_SalesTaxRate>();
            Sales_SalesTerritory = new FakeDbSet<Sales_SalesTerritory>();
            Sales_SalesTerritoryHistory = new FakeDbSet<Sales_SalesTerritoryHistory>();
            Sales_ShoppingCartItem = new FakeDbSet<Sales_ShoppingCartItem>();
            Sales_SpecialOffer = new FakeDbSet<Sales_SpecialOffer>();
            Sales_SpecialOfferProduct = new FakeDbSet<Sales_SpecialOfferProduct>();
            Sales_Store = new FakeDbSet<Sales_Store>();
            Sales_VIndividualCustomer = new FakeDbSet<Sales_VIndividualCustomer>();
            Sales_VPersonDemographic = new FakeDbSet<Sales_VPersonDemographic>();
            Sales_VSalesPerson = new FakeDbSet<Sales_VSalesPerson>();
            Sales_VSalesPersonSalesByFiscalYear = new FakeDbSet<Sales_VSalesPersonSalesByFiscalYear>();
            Sales_VStoreWithAddress = new FakeDbSet<Sales_VStoreWithAddress>();
            Sales_VStoreWithContact = new FakeDbSet<Sales_VStoreWithContact>();
            Sales_VStoreWithDemographic = new FakeDbSet<Sales_VStoreWithDemographic>();
        }

        public int SaveChanges()
        {
            return 0;
        }

        public void Dispose()
        {
            throw new NotImplementedException(); 
        }
        
        // Stored Procedures
        public List<UspGetBillOfMaterialsReturnModel> UspGetBillOfMaterials(int startProductId, DateTime checkDate, out int procResult)
        {
 
            procResult = 0;
            return new List<UspGetBillOfMaterialsReturnModel>();
        }

        public List<UspGetEmployeeManagersReturnModel> UspGetEmployeeManagers(int businessEntityId, out int procResult)
        {
 
            procResult = 0;
            return new List<UspGetEmployeeManagersReturnModel>();
        }

        public List<UspGetManagerEmployeesReturnModel> UspGetManagerEmployees(int businessEntityId, out int procResult)
        {
 
            procResult = 0;
            return new List<UspGetManagerEmployeesReturnModel>();
        }

        public List<UspGetWhereUsedProductIdReturnModel> UspGetWhereUsedProductId(int startProductId, DateTime checkDate, out int procResult)
        {
 
            procResult = 0;
            return new List<UspGetWhereUsedProductIdReturnModel>();
        }

        public int UspLogError(out int errorLogId)
        {
            errorLogId = default(int);
 
            return 0;
        }

        public int UspSearchCandidateResumes(string searchString, bool useInflectional, bool useThesaurus, int language)
        {
 
            return 0;
        }

        public int HumanResources_HumanResources_UspUpdateEmployeeHireInfo(int businessEntityId, string jobTitle, DateTime hireDate, DateTime rateChangeDate, decimal rate, byte payFrequency, bool currentFlag)
        {
 
            return 0;
        }

        public int HumanResources_HumanResources_UspUpdateEmployeeLogin(int businessEntityId, string organizationNode, string loginId, string jobTitle, DateTime hireDate, bool currentFlag)
        {
 
            return 0;
        }

        public int HumanResources_HumanResources_UspUpdateEmployeePersonalInfo(int businessEntityId, string nationalIdNumber, DateTime birthDate, string maritalStatus, string gender)
        {
 
            return 0;
        }

    }
}
