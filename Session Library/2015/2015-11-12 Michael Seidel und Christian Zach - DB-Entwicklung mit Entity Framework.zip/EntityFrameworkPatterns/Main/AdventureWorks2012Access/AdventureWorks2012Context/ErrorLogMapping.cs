// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context
{
    // ErrorLog
    internal partial class ErrorLogMapping : EntityTypeConfiguration<ErrorLog>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public ErrorLogMapping(string schema = "dbo")
        {
            ToTable(schema + ".ErrorLog");
            HasKey(x => x.ErrorLogId);

            Property(x => x.ErrorLogId).HasColumnName("ErrorLogID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(x => x.ErrorTime).HasColumnName("ErrorTime").IsRequired();
            Property(x => x.UserName).HasColumnName("UserName").IsRequired().HasMaxLength(128);
            Property(x => x.ErrorNumber).HasColumnName("ErrorNumber").IsRequired();
            Property(x => x.ErrorSeverity).HasColumnName("ErrorSeverity").IsOptional();
            Property(x => x.ErrorState).HasColumnName("ErrorState").IsOptional();
            Property(x => x.ErrorProcedure).HasColumnName("ErrorProcedure").IsOptional().HasMaxLength(126);
            Property(x => x.ErrorLine).HasColumnName("ErrorLine").IsOptional();
            Property(x => x.ErrorMessage).HasColumnName("ErrorMessage").IsRequired().HasMaxLength(4000);
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
