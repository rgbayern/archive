// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Production
{
    // ProductDescription
    internal partial class Production_ProductDescriptionMapping : EntityTypeConfiguration<Production_ProductDescription>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_ProductDescriptionMapping(string schema = "Production")
        {
            ToTable(schema + ".ProductDescription");
            HasKey(x => x.ProductDescriptionId);

            Property(x => x.ProductDescriptionId).HasColumnName("ProductDescriptionID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(x => x.Description).HasColumnName("Description").IsRequired().HasMaxLength(400);
            Property(x => x.Rowguid).HasColumnName("rowguid").IsRequired();
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
