// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;

namespace AdventureWorks2012Access.AdventureWorks2012Context.Production
{
    // ProductModelIllustration
    internal partial class Production_ProductModelIllustrationMapping : EntityTypeConfiguration<Production_ProductModelIllustration>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_ProductModelIllustrationMapping(string schema = "Production")
        {
            ToTable(schema + ".ProductModelIllustration");
            HasKey(x => new { x.ProductModelId, x.IllustrationId });

            Property(x => x.ProductModelId).HasColumnName("ProductModelID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.IllustrationId).HasColumnName("IllustrationID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(x => x.ModifiedDate).HasColumnName("ModifiedDate").IsRequired();

            // Foreign keys
            HasRequired(a => a.Production_ProductModel).WithMany(b => b.Production_ProductModelIllustration).HasForeignKey(c => c.ProductModelId); // FK_ProductModelIllustration_ProductModel_ProductModelID
            HasRequired(a => a.Production_Illustration).WithMany(b => b.Production_ProductModelIllustration).HasForeignKey(c => c.IllustrationId); // FK_ProductModelIllustration_Illustration_IllustrationID
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
