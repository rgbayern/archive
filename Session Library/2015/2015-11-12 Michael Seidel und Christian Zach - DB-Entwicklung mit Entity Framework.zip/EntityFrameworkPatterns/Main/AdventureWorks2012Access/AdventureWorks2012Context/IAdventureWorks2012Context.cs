// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.Collections.Generic;
using System.Data.Entity;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Purchasing;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace AdventureWorks2012Access.AdventureWorks2012Context
{
    public interface IAdventureWorks2012Context : IDisposable
    {
        DbSet<AwBuildVersion> AwBuildVersions { get; set; } // AWBuildVersion
        DbSet<DatabaseLog> DatabaseLogs { get; set; } // DatabaseLog
        DbSet<ErrorLog> ErrorLogs { get; set; } // ErrorLog
        DbSet<HumanResources_Department> HumanResources_Department { get; set; } // Department
        DbSet<HumanResources_Employee> HumanResources_Employee { get; set; } // Employee
        DbSet<HumanResources_EmployeeDepartmentHistory> HumanResources_EmployeeDepartmentHistory { get; set; } // EmployeeDepartmentHistory
        DbSet<HumanResources_EmployeePayHistory> HumanResources_EmployeePayHistory { get; set; } // EmployeePayHistory
        DbSet<HumanResources_JobCandidate> HumanResources_JobCandidate { get; set; } // JobCandidate
        DbSet<HumanResources_Shift> HumanResources_Shift { get; set; } // Shift
        DbSet<HumanResources_VEmployee> HumanResources_VEmployee { get; set; } // vEmployee
        DbSet<HumanResources_VEmployeeDepartment> HumanResources_VEmployeeDepartment { get; set; } // vEmployeeDepartment
        DbSet<HumanResources_VEmployeeDepartmentHistory> HumanResources_VEmployeeDepartmentHistory { get; set; } // vEmployeeDepartmentHistory
        DbSet<HumanResources_VJobCandidate> HumanResources_VJobCandidate { get; set; } // vJobCandidate
        DbSet<HumanResources_VJobCandidateEducation> HumanResources_VJobCandidateEducation { get; set; } // vJobCandidateEducation
        DbSet<HumanResources_VJobCandidateEmployment> HumanResources_VJobCandidateEmployment { get; set; } // vJobCandidateEmployment
        DbSet<Person_Address> Person_Address { get; set; } // Address
        DbSet<Person_AddressType> Person_AddressType { get; set; } // AddressType
        DbSet<Person_BusinessEntity> Person_BusinessEntity { get; set; } // BusinessEntity
        DbSet<Person_BusinessEntityAddress> Person_BusinessEntityAddress { get; set; } // BusinessEntityAddress
        DbSet<Person_BusinessEntityContact> Person_BusinessEntityContact { get; set; } // BusinessEntityContact
        DbSet<Person_ContactType> Person_ContactType { get; set; } // ContactType
        DbSet<Person_CountryRegion> Person_CountryRegion { get; set; } // CountryRegion
        DbSet<Person_EmailAddress> Person_EmailAddress { get; set; } // EmailAddress
        DbSet<Person_Password> Person_Password { get; set; } // Password
        DbSet<Person_Person> Person_Person { get; set; } // Person
        DbSet<Person_PersonPhone> Person_PersonPhone { get; set; } // PersonPhone
        DbSet<Person_PhoneNumberType> Person_PhoneNumberType { get; set; } // PhoneNumberType
        DbSet<Person_StateProvince> Person_StateProvince { get; set; } // StateProvince
        DbSet<Person_VAdditionalContactInfo> Person_VAdditionalContactInfo { get; set; } // vAdditionalContactInfo
        DbSet<Person_VStateProvinceCountryRegion> Person_VStateProvinceCountryRegion { get; set; } // vStateProvinceCountryRegion
        DbSet<Production_BillOfMaterial> Production_BillOfMaterial { get; set; } // BillOfMaterials
        DbSet<Production_Culture> Production_Culture { get; set; } // Culture
        DbSet<Production_Document> Production_Document { get; set; } // Document
        DbSet<Production_Illustration> Production_Illustration { get; set; } // Illustration
        DbSet<Production_Location> Production_Location { get; set; } // Location
        DbSet<Production_Product> Production_Product { get; set; } // Product
        DbSet<Production_ProductCategory> Production_ProductCategory { get; set; } // ProductCategory
        DbSet<Production_ProductCostHistory> Production_ProductCostHistory { get; set; } // ProductCostHistory
        DbSet<Production_ProductDescription> Production_ProductDescription { get; set; } // ProductDescription
        DbSet<Production_ProductDocument> Production_ProductDocument { get; set; } // ProductDocument
        DbSet<Production_ProductInventory> Production_ProductInventory { get; set; } // ProductInventory
        DbSet<Production_ProductListPriceHistory> Production_ProductListPriceHistory { get; set; } // ProductListPriceHistory
        DbSet<Production_ProductModel> Production_ProductModel { get; set; } // ProductModel
        DbSet<Production_ProductModelIllustration> Production_ProductModelIllustration { get; set; } // ProductModelIllustration
        DbSet<Production_ProductModelProductDescriptionCulture> Production_ProductModelProductDescriptionCulture { get; set; } // ProductModelProductDescriptionCulture
        DbSet<Production_ProductPhoto> Production_ProductPhoto { get; set; } // ProductPhoto
        DbSet<Production_ProductProductPhoto> Production_ProductProductPhoto { get; set; } // ProductProductPhoto
        DbSet<Production_ProductReview> Production_ProductReview { get; set; } // ProductReview
        DbSet<Production_ProductSubcategory> Production_ProductSubcategory { get; set; } // ProductSubcategory
        DbSet<Production_ScrapReason> Production_ScrapReason { get; set; } // ScrapReason
        DbSet<Production_TransactionHistory> Production_TransactionHistory { get; set; } // TransactionHistory
        DbSet<Production_TransactionHistoryArchive> Production_TransactionHistoryArchive { get; set; } // TransactionHistoryArchive
        DbSet<Production_UnitMeasure> Production_UnitMeasure { get; set; } // UnitMeasure
        DbSet<Production_VProductAndDescription> Production_VProductAndDescription { get; set; } // vProductAndDescription
        DbSet<Production_VProductModelCatalogDescription> Production_VProductModelCatalogDescription { get; set; } // vProductModelCatalogDescription
        DbSet<Production_VProductModelInstruction> Production_VProductModelInstruction { get; set; } // vProductModelInstructions
        DbSet<Production_WorkOrder> Production_WorkOrder { get; set; } // WorkOrder
        DbSet<Production_WorkOrderRouting> Production_WorkOrderRouting { get; set; } // WorkOrderRouting
        DbSet<Purchasing_ProductVendor> Purchasing_ProductVendor { get; set; } // ProductVendor
        DbSet<Purchasing_PurchaseOrderDetail> Purchasing_PurchaseOrderDetail { get; set; } // PurchaseOrderDetail
        DbSet<Purchasing_PurchaseOrderHeader> Purchasing_PurchaseOrderHeader { get; set; } // PurchaseOrderHeader
        DbSet<Purchasing_ShipMethod> Purchasing_ShipMethod { get; set; } // ShipMethod
        DbSet<Purchasing_Vendor> Purchasing_Vendor { get; set; } // Vendor
        DbSet<Purchasing_VVendorWithAddress> Purchasing_VVendorWithAddress { get; set; } // vVendorWithAddresses
        DbSet<Purchasing_VVendorWithContact> Purchasing_VVendorWithContact { get; set; } // vVendorWithContacts
        DbSet<Sales_CountryRegionCurrency> Sales_CountryRegionCurrency { get; set; } // CountryRegionCurrency
        DbSet<Sales_CreditCard> Sales_CreditCard { get; set; } // CreditCard
        DbSet<Sales_Currency> Sales_Currency { get; set; } // Currency
        DbSet<Sales_CurrencyRate> Sales_CurrencyRate { get; set; } // CurrencyRate
        DbSet<Sales_Customer> Sales_Customer { get; set; } // Customer
        DbSet<Sales_PersonCreditCard> Sales_PersonCreditCard { get; set; } // PersonCreditCard
        DbSet<Sales_SalesOrderDetail> Sales_SalesOrderDetail { get; set; } // SalesOrderDetail
        DbSet<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; } // SalesOrderHeader
        DbSet<Sales_SalesOrderHeaderSalesReason> Sales_SalesOrderHeaderSalesReason { get; set; } // SalesOrderHeaderSalesReason
        DbSet<Sales_SalesPerson> Sales_SalesPerson { get; set; } // SalesPerson
        DbSet<Sales_SalesPersonQuotaHistory> Sales_SalesPersonQuotaHistory { get; set; } // SalesPersonQuotaHistory
        DbSet<Sales_SalesReason> Sales_SalesReason { get; set; } // SalesReason
        DbSet<Sales_SalesTaxRate> Sales_SalesTaxRate { get; set; } // SalesTaxRate
        DbSet<Sales_SalesTerritory> Sales_SalesTerritory { get; set; } // SalesTerritory
        DbSet<Sales_SalesTerritoryHistory> Sales_SalesTerritoryHistory { get; set; } // SalesTerritoryHistory
        DbSet<Sales_ShoppingCartItem> Sales_ShoppingCartItem { get; set; } // ShoppingCartItem
        DbSet<Sales_SpecialOffer> Sales_SpecialOffer { get; set; } // SpecialOffer
        DbSet<Sales_SpecialOfferProduct> Sales_SpecialOfferProduct { get; set; } // SpecialOfferProduct
        DbSet<Sales_Store> Sales_Store { get; set; } // Store
        DbSet<Sales_VIndividualCustomer> Sales_VIndividualCustomer { get; set; } // vIndividualCustomer
        DbSet<Sales_VPersonDemographic> Sales_VPersonDemographic { get; set; } // vPersonDemographics
        DbSet<Sales_VSalesPerson> Sales_VSalesPerson { get; set; } // vSalesPerson
        DbSet<Sales_VSalesPersonSalesByFiscalYear> Sales_VSalesPersonSalesByFiscalYear { get; set; } // vSalesPersonSalesByFiscalYears
        DbSet<Sales_VStoreWithAddress> Sales_VStoreWithAddress { get; set; } // vStoreWithAddresses
        DbSet<Sales_VStoreWithContact> Sales_VStoreWithContact { get; set; } // vStoreWithContacts
        DbSet<Sales_VStoreWithDemographic> Sales_VStoreWithDemographic { get; set; } // vStoreWithDemographics

        int SaveChanges();
        
        // Stored Procedures
        List<UspGetBillOfMaterialsReturnModel> UspGetBillOfMaterials(int startProductId, DateTime checkDate, out int procResult);
        List<UspGetEmployeeManagersReturnModel> UspGetEmployeeManagers(int businessEntityId, out int procResult);
        List<UspGetManagerEmployeesReturnModel> UspGetManagerEmployees(int businessEntityId, out int procResult);
        List<UspGetWhereUsedProductIdReturnModel> UspGetWhereUsedProductId(int startProductId, DateTime checkDate, out int procResult);
        int UspLogError(out int errorLogId);
        int UspSearchCandidateResumes(string searchString, bool useInflectional, bool useThesaurus, int language);
        int HumanResources_HumanResources_UspUpdateEmployeeHireInfo(int businessEntityId, string jobTitle, DateTime hireDate, DateTime rateChangeDate, decimal rate, byte payFrequency, bool currentFlag);
        int HumanResources_HumanResources_UspUpdateEmployeeLogin(int businessEntityId, string organizationNode, string loginId, string jobTitle, DateTime hireDate, bool currentFlag);
        int HumanResources_HumanResources_UspUpdateEmployeePersonalInfo(int businessEntityId, string nationalIdNumber, DateTime birthDate, string maritalStatus, string gender);
    }

}
