// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Data.Entity.ModelConfiguration;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources;

namespace AdventureWorks2012Access.AdventureWorks2012Context.HumanResources
{
    // vEmployeeDepartmentHistory
    internal partial class HumanResources_VEmployeeDepartmentHistoryMapping : EntityTypeConfiguration<HumanResources_VEmployeeDepartmentHistory>
    {
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public HumanResources_VEmployeeDepartmentHistoryMapping(string schema = "HumanResources")
        {
            ToTable(schema + ".vEmployeeDepartmentHistory");
            HasKey(x => new { x.BusinessEntityId, x.FirstName, x.LastName, x.Shift, x.Department, x.GroupName, x.StartDate });

            Property(x => x.BusinessEntityId).HasColumnName("BusinessEntityID").IsRequired();
            Property(x => x.Title).HasColumnName("Title").IsOptional().HasMaxLength(8);
            Property(x => x.FirstName).HasColumnName("FirstName").IsRequired().HasMaxLength(50);
            Property(x => x.MiddleName).HasColumnName("MiddleName").IsOptional().HasMaxLength(50);
            Property(x => x.LastName).HasColumnName("LastName").IsRequired().HasMaxLength(50);
            Property(x => x.Suffix).HasColumnName("Suffix").IsOptional().HasMaxLength(10);
            Property(x => x.Shift).HasColumnName("Shift").IsRequired().HasMaxLength(50);
            Property(x => x.Department).HasColumnName("Department").IsRequired().HasMaxLength(50);
            Property(x => x.GroupName).HasColumnName("GroupName").IsRequired().HasMaxLength(50);
            Property(x => x.StartDate).HasColumnName("StartDate").IsRequired();
            Property(x => x.EndDate).HasColumnName("EndDate").IsOptional();
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
