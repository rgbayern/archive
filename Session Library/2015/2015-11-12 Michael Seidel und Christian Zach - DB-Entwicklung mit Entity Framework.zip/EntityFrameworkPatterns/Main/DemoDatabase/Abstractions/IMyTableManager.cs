﻿using System.Collections.Generic;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Abstractions
{
    internal interface IMyTableManager : IMyTableWriterPublic, IMyTableReader
    {
    }
}
