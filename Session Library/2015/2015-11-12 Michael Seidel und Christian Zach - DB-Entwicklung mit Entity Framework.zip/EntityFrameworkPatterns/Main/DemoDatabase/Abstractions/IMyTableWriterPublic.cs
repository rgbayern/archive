﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Abstractions
{
    interface IMyTableWriterPublic
    {
        int Add(MyTable myTableToAdd);
        int AddMany(IEnumerable<MyTable> itemsToAdd);
        int Update1(MyTable item);
        int Update2(MyTable item);
        int AddOrUpdate(IEnumerable<MyTable> itemsToAddOrUpdate);
    }
}
