﻿using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Abstractions
{
    internal interface IMyTableHistoryWriter
    {
        void Add(DemoContext context, MyTable item);
    }
}
