﻿using System.Collections.Generic;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Abstractions
{
    internal interface IMyTableReader
    {
        IEnumerable<MyTable> GetAllItems();
        IEnumerable<int> GetNumbersOfToday();
        MyTable GetFirst();
    }
}
