﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Abstractions
{
    internal interface IMyTableWriter : IMyTableWriterPublic
    {
        void Update1(DemoContext context, MyTable item);
        int Remove(Expression<Func<MyTable, bool>> predicate);
        int Remove(IEnumerable<MyTable> itemsToRemove);
    }
}
