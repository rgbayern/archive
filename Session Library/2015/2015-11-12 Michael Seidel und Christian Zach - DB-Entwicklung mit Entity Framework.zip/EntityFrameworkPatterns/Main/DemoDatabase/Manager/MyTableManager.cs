﻿using System.Collections.Generic;
using DemoDatabase.Abstractions;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Manager
{
    internal class MyTableManager : IMyTableManager
    {
        private readonly IMyTableWriter _writer;
        private readonly IMyTableReader _reader;
        private readonly IMyTableHistoryWriter _historyWriter;
        private readonly IContextFactory _contextFactory;

        public MyTableManager(IMyTableWriter writer, IMyTableReader reader, IMyTableHistoryWriter historyWriter, IContextFactory contextFactory)
        {
            _writer = writer;
            _reader = reader;
            _historyWriter = historyWriter;
            _contextFactory = contextFactory;
        }

        public int Add(MyTable myTableToAdd)
        {
            return _writer.Add(myTableToAdd);
        }

        public int AddMany(IEnumerable<MyTable> itemsToAdd)
        {
            return _writer.AddMany(itemsToAdd);
        }

        public int Update1(MyTable item)
        {
            var context = _contextFactory.CreateTrackingContext<DemoContext>();
            _historyWriter.Add(context, item);
            _writer.Update1(context, item);
            return context.SaveChanges();
        }

        public int Update2(MyTable item)
        {
            return _writer.Update2(item);
        }

        public int AddOrUpdate(IEnumerable<MyTable> itemsToAddOrUpdate)
        {
            return _writer.AddOrUpdate(itemsToAddOrUpdate);
        }

        public IEnumerable<MyTable> GetAllItems()
        {
            return _reader.GetAllItems();
        }

        public IEnumerable<int> GetNumbersOfToday()
        {
            return _reader.GetNumbersOfToday();
        }

        public MyTable GetFirst()
        {
            return _reader.GetFirst();
        }
    }
}
