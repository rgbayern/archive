﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoDatabase.Abstractions;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Writer
{
    internal class MyTableHistoryWriter : IMyTableHistoryWriter
    {
        public void Add(DemoContext context, MyTable item)
        {
            context.MyTableHistory.Add(new MyTableHistory(item));
        }
    }
}
