﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using DemoDatabase.Abstractions;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.Library.CommonExtensions;

namespace DemoDatabase.Writer
{
    internal class MyTableWriter : IMyTableWriter
    {
        private readonly IContextFactory _contextFactory;

        public MyTableWriter(IContextFactory contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public int Add(MyTable myTableToAdd)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                context.MyTable.Add(myTableToAdd);
                return context.SaveChanges();
            }
        }

        public int AddMany(IEnumerable<MyTable> itemsToAdd)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                context.DoUndetected<DemoContext>(c => itemsToAdd.ToList().ForEach(item => c.Set<MyTable>().Add(item)));
                return context.SaveChanges();
            }
        }

        public int Update1(MyTable item)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                Update1(context, item);
                return context.SaveChanges();
            }
        }

        public void Update1(DemoContext context, MyTable item)
        {
            context.MyTable.Attach(item);
            context.Entry(item).State = EntityState.Modified;
        }

        public int Update2(MyTable item)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                var itemToUpdate = context.MyTable.Find(item.Id);
                context.Entry(itemToUpdate).CurrentValues.SetValues(item);
                return context.SaveChanges();
            }
        }

        public int AddOrUpdate(IEnumerable<MyTable> itemsToAddOrUpdate)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                var toAddOrUpdate = itemsToAddOrUpdate as MyTable[] ?? itemsToAddOrUpdate.ToArray();

                var keyArray = toAddOrUpdate.Select(item => item.Id).ToArray();

                var itemsToUpdate = context.MyTable.Where(item => keyArray.Contains(item.Id)).ToList();
                var valuePairs = itemsToUpdate.Join(toAddOrUpdate, x => x.Id, y => y.Id,
                    (x, y) => new UpdateData<MyTable> { Database = x, Memory = y }).ToList();
                valuePairs.ForEach(pair => context.Entry(pair.Database).CurrentValues.SetValues(pair.Memory));

                var itemsToAdd = toAddOrUpdate.LeftExcludingJoin(itemsToUpdate, x => x.Id, y => y.Id, (x, y) => x).ToArray();
                context.DoUndetected<DemoContext>(dbContext => itemsToAdd.ToList().ForEach(item => dbContext.Set<MyTable>().Add(item)));

                return context.SaveChanges();
            }
        }

        public int Remove(Expression<Func<MyTable, bool>> predicate)
        {
            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                var itemsToRemove = context.MyTable.Where(predicate).ToArray();
                if (itemsToRemove.Any() == false) return 0;
                context.MyTable.RemoveRange(itemsToRemove);
                return context.SaveChanges();
            }
        }

        public int Remove(IEnumerable<MyTable> itemsToRemove)
        {
            var keyArray = itemsToRemove.Select(item => item.Id).ToArray();

            using (var context = _contextFactory.CreateTrackingContext<DemoContext>())
            {
                var items = context.MyTable.Where(item => keyArray.Contains(item.Id)).ToList();
                context.MyTable.RemoveRange(items);
                return context.SaveChanges();
            }
        }

        private class UpdateData<T>
        {
            public T Memory { get; set; }
            public T Database { get; set; }
        }
    }
}
