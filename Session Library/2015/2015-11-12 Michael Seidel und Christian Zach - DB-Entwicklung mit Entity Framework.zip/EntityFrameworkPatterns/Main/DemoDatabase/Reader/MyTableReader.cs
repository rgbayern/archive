﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using DemoDatabase.Abstractions;
using EntityFrameworkPatterns.Components.DbAccess_;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace DemoDatabase.Reader
{
    internal class MyTableReader : GenericDataReader<DemoContext, MyTable>, IMyTableReader
    {
        public MyTableReader(IContextFactory contextFactory)
            : base(contextFactory)
        {
        }

        public IEnumerable<MyTable> GetAllItems()
        {
            return GetAll();
        }

        public IEnumerable<int> GetNumbersOfToday()
        {
            return GetList(item => item.Time.Date == DateTime.Today.Date, match => match.Number).ToList();
        }

        public MyTable GetFirst()
        {
            return GetFirst(item => true, x => x);
        }
    }
}
