﻿using System.ComponentModel.Composition;
using DemoDatabase.Abstractions;
using DemoDatabase.Manager;
using DemoDatabase.Reader;
using DemoDatabase.Writer;
using EntityFrameworkPatterns.OperationContracts;

namespace DemoDatabase
{
    [Export(typeof(IModule))]
    public class ModuleInit : IModule
    {
        public void Initialize(IModuleRegistrar registrar)
        {
            registrar.RegisterAsSingleton<IMyTableWriter, MyTableWriter>();
            registrar.RegisterAsSingleton<IMyTableHistoryWriter, MyTableHistoryWriter>();

            registrar.RegisterAsSingleton<IMyTableReader, MyTableReader>();

            registrar.RegisterAsSingleton<IMyTableManager, MyTableManager>();

            registrar.RegisterAsSingleton<IDemoDatabaseAccessForConsole, DemoDatabaseAccess>();
        }
    }
}
