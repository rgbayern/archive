﻿using System.Collections.Generic;
using DemoDatabase.Abstractions;
using DemoDatabase.Manager;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts;

namespace DemoDatabase
{
    /// <summary>
    /// Fassade für den Datenbankzugriff
    /// </summary>
    internal class DemoDatabaseAccess : IDemoDatabaseAccessForConsole
    {
        // Komponenten hinter der Fassade
        private readonly IMyTableManager _myTableManager;


        public DemoDatabaseAccess(IMyTableManager myTableManager)
        {
            _myTableManager = myTableManager;
        }

        public int Add(MyTable data)
        {
            return _myTableManager.Add(data);
        }

        public IEnumerable<MyTable> GetAllItems()
        {
            return _myTableManager.GetAllItems();
        }
    }
}
