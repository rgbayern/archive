﻿using System.ComponentModel.Composition;
using EntityFrameworkPatterns.OperationContracts;

namespace SomeMyTableBusiness
{
    [Export(typeof(IModule))]
    public class ModuleInit : IModule
    {
        public void Initialize(IModuleRegistrar registrar)
        {
            registrar.RegisterAsSingleton<IMyTableBusiness, MyTableBusiness>();
            registrar.RegisterAsSingleton<IMyTableBusinessAdvanced, MyTableBusinessAdvanced>();
        }
    }
}
