﻿using System;
using DbAccessCQRS.DemoDatabase.Query;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace SomeMyTableBusiness
{
    internal class MyTableBusinessAdvanced : IMyTableBusinessAdvanced
    {
        private readonly IQueryProcessor _queryProcessor;

        public MyTableBusinessAdvanced(IQueryProcessor queryProcessor)
        {
            _queryProcessor = queryProcessor;
        }

        public MyTable[] UseTheQuery()
        {
            var query = new FindMyTableByDateQuery(DateTime.Today);
            return _queryProcessor.Process(query);
        }

        public MyTable UseTheFirstOrDefaultQuery()
        {
            var query = new FindFirstMyTableInSpecialOrderQuery();
            return _queryProcessor.Process(query);
        }
    }
}
