﻿using System;
using DbAccessCQRS.DemoDatabase.Query;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;
using EntityFrameworkPatterns.OperationContracts;
using EntityFrameworkPatterns.OperationContracts.CQRS;

namespace SomeMyTableBusiness
{
    internal class MyTableBusiness : IMyTableBusiness
    {
        private readonly IQueryHandler<FindMyTableByDateQuery, MyTable[]> _findMyTableByDateQueryhandler;
        private readonly IQueryHandler<FindFirstMyTableInSpecialOrderQuery, MyTable> _findFirstMyTableInSpecialOrderQueryHandler;

        public MyTableBusiness(IQueryHandler<FindMyTableByDateQuery, MyTable[]> findMyTableByDateQueryhandler, 
            IQueryHandler<FindFirstMyTableInSpecialOrderQuery, MyTable> findFirstMyTableInSpecialOrderQueryHandler)
        {
            _findMyTableByDateQueryhandler = findMyTableByDateQueryhandler;
            _findFirstMyTableInSpecialOrderQueryHandler = findFirstMyTableInSpecialOrderQueryHandler;
        }

        public MyTable[] UseTheQuery()
        {
            var query = new FindMyTableByDateQuery(DateTime.Today);
            return _findMyTableByDateQueryhandler.Handle(query);
        }

        public MyTable UseTheFirstOrDefaultQuery()
        {
            var query = new FindFirstMyTableInSpecialOrderQuery();
            return _findFirstMyTableInSpecialOrderQueryHandler.Handle(query);
        }
    }
}
