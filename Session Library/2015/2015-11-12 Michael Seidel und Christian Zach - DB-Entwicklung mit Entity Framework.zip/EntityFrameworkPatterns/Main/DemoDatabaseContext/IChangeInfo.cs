﻿using System;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public interface IChangeInfo
    {
        DateTime Modified { get; set; }
    }
}