namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class HistoryWriter : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MyTableHistories",
                c => new
                    {
                        MyTableHistoryId = c.Guid(nullable: false),
                        Modified = c.DateTime(nullable: false),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.MyTableHistoryId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.MyTableHistories");
        }
    }
}
