namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ModifiedAdded : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Categories", "Modified", c => c.DateTime(nullable: false));
            AddColumn("dbo.Products", "Modified", c => c.DateTime(nullable: false));
            AddColumn("dbo.MyTables", "Modified", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.MyTables", "Modified");
            DropColumn("dbo.Products", "Modified");
            DropColumn("dbo.Categories", "Modified");
        }
    }
}
