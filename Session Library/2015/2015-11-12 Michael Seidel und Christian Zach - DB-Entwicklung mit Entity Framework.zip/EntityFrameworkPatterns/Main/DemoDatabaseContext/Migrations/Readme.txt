﻿
https://coding.abel.nu/2012/03/ef-migrations-command-reference/

Alle Befehle werden in die Paketmanager-Console eingegeben.
("View" -> "Other Windows" -> "Package Manager Console")

-----------------------------------------------------------

Enable-Migrations	-> Fügt einem Projekt die Migration hinzu. 

Add-Migration		-> Erstellt eine Migration für aktuell ausstehende Änderungen.

Update-Database		-> Führt notwendige Migration(en) auf einer Datenbank aus.

Get-Migrations		-> Zeigt die Migrationen einer Zieldatenbank.
