﻿using System;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public class Category : IChangeInfo
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }

        public virtual ObservableListSource<Product> Products { get; } = new ObservableListSource<Product>();

        public DateTime Modified { get; set; }
    }
}