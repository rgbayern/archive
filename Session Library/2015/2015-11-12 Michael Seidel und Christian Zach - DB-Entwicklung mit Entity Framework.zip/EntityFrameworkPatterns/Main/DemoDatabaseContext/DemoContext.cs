﻿using System;
using System.Data.Entity;
using System.Linq;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public class DemoContext : DbContext
    {
        #region Konstruktor
        public DemoContext()
            : base()
        {

        }

        public DemoContext(string connectionString)
            : base(connectionString)
        {

        }
        #endregion

        public virtual DbSet<MyTable> MyTable { get; set; }
        public virtual DbSet<MyTableHistory> MyTableHistory { get; set; }

        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Product> Products { get; set; }

        public virtual DbSet<Actor> Actors { get; set; }
        public virtual DbSet<Movie> Movies { get; set; }

        #region SaveChanges
        public override int SaveChanges()
        {
            foreach (var dbEntityEntry in this.ChangeTracker.Entries()
                .Where(entry => entry.Entity is IChangeInfo
                    && ((entry.State == EntityState.Added) || entry.State == EntityState.Modified)))
            {
                ((IChangeInfo)dbEntityEntry.Entity).Modified = DateTime.Now;
            }

            return base.SaveChanges();
        }
        #endregion
    }
}
