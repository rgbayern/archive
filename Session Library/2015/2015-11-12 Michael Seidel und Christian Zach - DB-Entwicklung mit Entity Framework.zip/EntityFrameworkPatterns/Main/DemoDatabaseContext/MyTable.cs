﻿using System;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    [DataContract]
    public class MyTable : IChangeInfo
    {
        [DataMember(Order = 1)]
        public Guid Id { get; set; }

        [DataMember(Order = 2)]
        public DateTime Modified { get; set; }

        [DataMember(Order = 3)]
        public int Number { get; set; }

        [DataMember(Order = 4)]
        public DateTime Time { get; set; }

        [DataMember(Order = 5)]
        public string Name { get; set; }
    }
}
