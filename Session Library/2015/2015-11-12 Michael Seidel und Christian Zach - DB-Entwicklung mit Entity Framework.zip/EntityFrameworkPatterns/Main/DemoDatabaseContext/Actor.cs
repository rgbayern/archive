using System;
using System.Collections.Generic;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public class Actor : IChangeInfo
    {
        public Guid ActorId { get; set; }

        public DateTime Modified { get; set; }

        public virtual ICollection<Movie> ActorMovies { get; set; }
    }
}