﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public class Movie : IChangeInfo
    {
        public Guid MovieId { get; set; }
        public DateTime Modified { get; set; }

        public string Title { get; set; }

        public virtual ICollection<Actor> MovieActors { get; set; }
    }
}
