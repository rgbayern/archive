﻿using System;

namespace EntityFrameworkPatterns.Contexts.DemoDatabaseContext
{
    public class MyTableHistory : IChangeInfo
    {
        public MyTableHistory(MyTable item)
        {
            MyTableHistoryId = Guid.NewGuid();
            Name = item.Name;
        }

        public Guid MyTableHistoryId { get; set; }
        public DateTime Modified { get; set; }

        public string Name { get; set; }
    }
}
