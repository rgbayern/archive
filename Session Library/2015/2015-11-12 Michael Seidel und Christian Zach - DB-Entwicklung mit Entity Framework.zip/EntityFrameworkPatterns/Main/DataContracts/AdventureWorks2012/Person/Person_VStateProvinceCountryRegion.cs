// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person
{
    // vStateProvinceCountryRegion
    [DataContract]
    public partial class Person_VStateProvinceCountryRegion
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int StateProvinceId { get; set; } // StateProvinceID

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string StateProvinceCode { get; set; } // StateProvinceCode

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool IsOnlyStateProvinceFlag { get; set; } // IsOnlyStateProvinceFlag

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string StateProvinceName { get; set; } // StateProvinceName

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int TerritoryId { get; set; } // TerritoryID

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CountryRegionCode { get; set; } // CountryRegionCode

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CountryRegionName { get; set; } // CountryRegionName

    }

}
