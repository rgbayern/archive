// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person
{
    // StateProvince
    [DataContract]
    public partial class Person_StateProvince
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int StateProvinceId { get; set; } // StateProvinceID (Primary key). Primary key for StateProvince records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string StateProvinceCode { get; set; } // StateProvinceCode. ISO standard state or province code.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CountryRegionCode { get; set; } // CountryRegionCode. ISO standard country or region code. Foreign key to CountryRegion.CountryRegionCode.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool IsOnlyStateProvinceFlag { get; set; } // IsOnlyStateProvinceFlag. 0 = StateProvinceCode exists. 1 = StateProvinceCode unavailable, using CountryRegionCode.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. State or province description.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int TerritoryId { get; set; } // TerritoryID. ID of the territory in which the state or province is located. Foreign key to SalesTerritory.SalesTerritoryID.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Person_Address> Person_Address { get; set; } // Address.FK_Address_StateProvince_StateProvinceID
        public virtual ICollection<Sales_SalesTaxRate> Sales_SalesTaxRate { get; set; } // SalesTaxRate.FK_SalesTaxRate_StateProvince_StateProvinceID

        // Foreign keys
        public virtual Person_CountryRegion Person_CountryRegion { get; set; } // FK_StateProvince_CountryRegion_CountryRegionCode
        public virtual Sales_SalesTerritory Sales_SalesTerritory { get; set; } // FK_StateProvince_SalesTerritory_TerritoryID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Person_StateProvince()
        {
            IsOnlyStateProvinceFlag = true;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Person_Address = new List<Person_Address>();
            Sales_SalesTaxRate = new List<Sales_SalesTaxRate>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
