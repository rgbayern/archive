// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012
{
    public class UspGetEmployeeManagersReturnModel
    {
        public Int32? RecursionLevel { get; set; }
        public Int32? BusinessEntityId { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String OrganizationNode { get; set; }
        public String ManagerFirstName { get; set; }
        public String ManagerLastName { get; set; }
    }

}
