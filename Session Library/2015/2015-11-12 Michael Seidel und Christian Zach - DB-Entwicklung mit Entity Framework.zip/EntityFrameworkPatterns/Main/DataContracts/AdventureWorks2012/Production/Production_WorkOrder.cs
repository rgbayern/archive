// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production
{
    // WorkOrder
    [DataContract]
    public partial class Production_WorkOrder
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int WorkOrderId { get; set; } // WorkOrderID (Primary key). Primary key for WorkOrder records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductId { get; set; } // ProductID. Product identification number. Foreign key to Product.ProductID.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int OrderQty { get; set; } // OrderQty. Product quantity to build.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int StockedQty { get; internal set; } // StockedQty. Quantity built and put in inventory.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short ScrappedQty { get; set; } // ScrappedQty. Quantity that failed inspection.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime StartDate { get; set; } // StartDate. Work order start date.

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? EndDate { get; set; } // EndDate. Work order end date.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime DueDate { get; set; } // DueDate. Work order due date.

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short? ScrapReasonId { get; set; } // ScrapReasonID. Reason for inspection failure.

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Production_WorkOrderRouting> Production_WorkOrderRouting { get; set; } // Many to many mapping

        // Foreign keys
        public virtual Production_Product Production_Product { get; set; } // FK_WorkOrder_Product_ProductID
        public virtual Production_ScrapReason Production_ScrapReason { get; set; } // FK_WorkOrder_ScrapReason_ScrapReasonID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_WorkOrder()
        {
            ModifiedDate = System.DateTime.Now;
            Production_WorkOrderRouting = new List<Production_WorkOrderRouting>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
