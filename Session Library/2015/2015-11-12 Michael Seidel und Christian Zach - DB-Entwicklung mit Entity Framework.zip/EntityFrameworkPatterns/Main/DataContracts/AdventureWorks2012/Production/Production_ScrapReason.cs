// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production
{
    // ScrapReason
    [DataContract]
    public partial class Production_ScrapReason
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short ScrapReasonId { get; set; } // ScrapReasonID (Primary key). Primary key for ScrapReason records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. Failure description.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Production_WorkOrder> Production_WorkOrder { get; set; } // WorkOrder.FK_WorkOrder_ScrapReason_ScrapReasonID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_ScrapReason()
        {
            ModifiedDate = System.DateTime.Now;
            Production_WorkOrder = new List<Production_WorkOrder>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
