// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production
{
    // ProductPhoto
    [DataContract]
    public partial class Production_ProductPhoto
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductPhotoId { get; set; } // ProductPhotoID (Primary key). Primary key for ProductPhoto records.

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte[] ThumbNailPhoto { get; set; } // ThumbNailPhoto. Small image of the product.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ThumbnailPhotoFileName { get; set; } // ThumbnailPhotoFileName. Small image file name.

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte[] LargePhoto { get; set; } // LargePhoto. Large image of the product.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string LargePhotoFileName { get; set; } // LargePhotoFileName. Large image file name.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Production_ProductProductPhoto> Production_ProductProductPhoto { get; set; } // Many to many mapping
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_ProductPhoto()
        {
            ModifiedDate = System.DateTime.Now;
            Production_ProductProductPhoto = new List<Production_ProductProductPhoto>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
