// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production
{
    // ProductModel
    [DataContract]
    public partial class Production_ProductModel
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductModelId { get; set; } // ProductModelID (Primary key). Primary key for ProductModel records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. Product model description.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CatalogDescription { get; set; } // CatalogDescription. Detailed product catalog information in xml format.

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Instructions { get; set; } // Instructions. Manufacturing instructions in xml format.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Production_Product> Production_Product { get; set; } // Product.FK_Product_ProductModel_ProductModelID
        public virtual ICollection<Production_ProductModelIllustration> Production_ProductModelIllustration { get; set; } // Many to many mapping
        public virtual ICollection<Production_ProductModelProductDescriptionCulture> Production_ProductModelProductDescriptionCulture { get; set; } // Many to many mapping
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_ProductModel()
        {
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Production_Product = new List<Production_Product>();
            Production_ProductModelIllustration = new List<Production_ProductModelIllustration>();
            Production_ProductModelProductDescriptionCulture = new List<Production_ProductModelProductDescriptionCulture>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
