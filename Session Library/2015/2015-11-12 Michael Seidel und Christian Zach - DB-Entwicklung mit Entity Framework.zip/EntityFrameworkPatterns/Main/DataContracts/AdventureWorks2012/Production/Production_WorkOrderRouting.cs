// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production
{
    // WorkOrderRouting
    [DataContract]
    public partial class Production_WorkOrderRouting
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int WorkOrderId { get; set; } // WorkOrderID (Primary key). Primary key. Foreign key to WorkOrder.WorkOrderID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductId { get; set; } // ProductID (Primary key). Primary key. Foreign key to Product.ProductID.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short OperationSequence { get; set; } // OperationSequence (Primary key). Primary key. Indicates the manufacturing process sequence.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short LocationId { get; set; } // LocationID. Manufacturing location where the part is processed. Foreign key to Location.LocationID.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ScheduledStartDate { get; set; } // ScheduledStartDate. Planned manufacturing start date.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ScheduledEndDate { get; set; } // ScheduledEndDate. Planned manufacturing end date.

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? ActualStartDate { get; set; } // ActualStartDate. Actual start date.

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? ActualEndDate { get; set; } // ActualEndDate. Actual end date.

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal? ActualResourceHrs { get; set; } // ActualResourceHrs. Number of manufacturing hours used.

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal PlannedCost { get; set; } // PlannedCost. Estimated manufacturing cost.

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal? ActualCost { get; set; } // ActualCost. Actual manufacturing cost.

        [DataMember(Order = 12, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Foreign keys
        public virtual Production_Location Production_Location { get; set; } // FK_WorkOrderRouting_Location_LocationID
        public virtual Production_WorkOrder Production_WorkOrder { get; set; } // FK_WorkOrderRouting_WorkOrder_WorkOrderID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_WorkOrderRouting()
        {
            ModifiedDate = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
