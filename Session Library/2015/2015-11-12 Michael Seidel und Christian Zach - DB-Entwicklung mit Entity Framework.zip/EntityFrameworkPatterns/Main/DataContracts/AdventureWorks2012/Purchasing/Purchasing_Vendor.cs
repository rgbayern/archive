// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Purchasing
{
    // Vendor
    [DataContract]
    public partial class Purchasing_Vendor
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key for Vendor records.  Foreign key to BusinessEntity.BusinessEntityID

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string AccountNumber { get; set; } // AccountNumber. Vendor account (identification) number.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. Company name.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte CreditRating { get; set; } // CreditRating. 1 = Superior, 2 = Excellent, 3 = Above average, 4 = Average, 5 = Below average

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool PreferredVendorStatus { get; set; } // PreferredVendorStatus. 0 = Do not use if another vendor is available. 1 = Preferred over other vendors supplying the same product.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool ActiveFlag { get; set; } // ActiveFlag. 0 = Vendor no longer used. 1 = Vendor is actively used.

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string PurchasingWebServiceUrl { get; set; } // PurchasingWebServiceURL. Vendor URL.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Purchasing_ProductVendor> Purchasing_ProductVendor { get; set; } // Many to many mapping
        public virtual ICollection<Purchasing_PurchaseOrderHeader> Purchasing_PurchaseOrderHeader { get; set; } // PurchaseOrderHeader.FK_PurchaseOrderHeader_Vendor_VendorID

        // Foreign keys
        public virtual Person_BusinessEntity Person_BusinessEntity { get; set; } // FK_Vendor_BusinessEntity_BusinessEntityID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Purchasing_Vendor()
        {
            PreferredVendorStatus = true;
            ActiveFlag = true;
            ModifiedDate = System.DateTime.Now;
            Purchasing_ProductVendor = new List<Purchasing_ProductVendor>();
            Purchasing_PurchaseOrderHeader = new List<Purchasing_PurchaseOrderHeader>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
