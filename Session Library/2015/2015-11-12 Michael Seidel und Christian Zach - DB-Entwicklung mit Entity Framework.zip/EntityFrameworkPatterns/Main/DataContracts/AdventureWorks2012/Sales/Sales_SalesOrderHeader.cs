// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Purchasing;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales
{
    // SalesOrderHeader
    [DataContract]
    public partial class Sales_SalesOrderHeader
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int SalesOrderId { get; set; } // SalesOrderID (Primary key). Primary key.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte RevisionNumber { get; set; } // RevisionNumber. Incremental number to track changes to the sales order over time.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime OrderDate { get; set; } // OrderDate. Dates the sales order was created.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime DueDate { get; set; } // DueDate. Date the order is due to the customer.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? ShipDate { get; set; } // ShipDate. Date the order was shipped to the customer.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte Status { get; set; } // Status. Order current status. 1 = In process; 2 = Approved; 3 = Backordered; 4 = Rejected; 5 = Shipped; 6 = Cancelled

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool OnlineOrderFlag { get; set; } // OnlineOrderFlag. 0 = Order placed by sales person. 1 = Order placed online by customer.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string SalesOrderNumber { get; internal set; } // SalesOrderNumber. Unique sales order identification number.

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string PurchaseOrderNumber { get; set; } // PurchaseOrderNumber. Customer purchase order number reference.

        [DataMember(Order = 10, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string AccountNumber { get; set; } // AccountNumber. Financial accounting number reference.

        [DataMember(Order = 11, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int CustomerId { get; set; } // CustomerID. Customer identification number. Foreign key to Customer.BusinessEntityID.

        [DataMember(Order = 12, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? SalesPersonId { get; set; } // SalesPersonID. Sales person who created the sales order. Foreign key to SalesPerson.BusinessEntityID.

        [DataMember(Order = 13, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? TerritoryId { get; set; } // TerritoryID. Territory in which the sale was made. Foreign key to SalesTerritory.SalesTerritoryID.

        [DataMember(Order = 14, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BillToAddressId { get; set; } // BillToAddressID. Customer billing address. Foreign key to Address.AddressID.

        [DataMember(Order = 15, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ShipToAddressId { get; set; } // ShipToAddressID. Customer shipping address. Foreign key to Address.AddressID.

        [DataMember(Order = 16, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ShipMethodId { get; set; } // ShipMethodID. Shipping method. Foreign key to ShipMethod.ShipMethodID.

        [DataMember(Order = 17, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? CreditCardId { get; set; } // CreditCardID. Credit card identification number. Foreign key to CreditCard.CreditCardID.

        [DataMember(Order = 18, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CreditCardApprovalCode { get; set; } // CreditCardApprovalCode. Approval code provided by the credit card company.

        [DataMember(Order = 19, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? CurrencyRateId { get; set; } // CurrencyRateID. Currency exchange rate used. Foreign key to CurrencyRate.CurrencyRateID.

        [DataMember(Order = 20, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal SubTotal { get; set; } // SubTotal. Sales subtotal. Computed as SUM(SalesOrderDetail.LineTotal)for the appropriate SalesOrderID.

        [DataMember(Order = 21, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal TaxAmt { get; set; } // TaxAmt. Tax amount.

        [DataMember(Order = 22, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal Freight { get; set; } // Freight. Shipping cost.

        [DataMember(Order = 23, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal TotalDue { get; internal set; } // TotalDue. Total due from customer. Computed as Subtotal + TaxAmt + Freight.

        [DataMember(Order = 24, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Comment { get; set; } // Comment. Sales representative comments.

        [DataMember(Order = 25, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 26, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_SalesOrderDetail> Sales_SalesOrderDetail { get; set; } // Many to many mapping
        public virtual ICollection<Sales_SalesOrderHeaderSalesReason> Sales_SalesOrderHeaderSalesReason { get; set; } // Many to many mapping

        // Foreign keys
        public virtual Person_Address Person_Address_BillToAddressId { get; set; } // FK_SalesOrderHeader_Address_BillToAddressID
        public virtual Person_Address Person_Address_ShipToAddressId { get; set; } // FK_SalesOrderHeader_Address_ShipToAddressID
        public virtual Purchasing_ShipMethod Purchasing_ShipMethod { get; set; } // FK_SalesOrderHeader_ShipMethod_ShipMethodID
        public virtual Sales_CreditCard Sales_CreditCard { get; set; } // FK_SalesOrderHeader_CreditCard_CreditCardID
        public virtual Sales_CurrencyRate Sales_CurrencyRate { get; set; } // FK_SalesOrderHeader_CurrencyRate_CurrencyRateID
        public virtual Sales_Customer Sales_Customer { get; set; } // FK_SalesOrderHeader_Customer_CustomerID
        public virtual Sales_SalesPerson Sales_SalesPerson { get; set; } // FK_SalesOrderHeader_SalesPerson_SalesPersonID
        public virtual Sales_SalesTerritory Sales_SalesTerritory { get; set; } // FK_SalesOrderHeader_SalesTerritory_TerritoryID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_SalesOrderHeader()
        {
            RevisionNumber = 0;
            OrderDate = System.DateTime.Now;
            Status = 1;
            OnlineOrderFlag = true;
            SubTotal = 0.00m;
            TaxAmt = 0.00m;
            Freight = 0.00m;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Sales_SalesOrderDetail = new List<Sales_SalesOrderDetail>();
            Sales_SalesOrderHeaderSalesReason = new List<Sales_SalesOrderHeaderSalesReason>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
