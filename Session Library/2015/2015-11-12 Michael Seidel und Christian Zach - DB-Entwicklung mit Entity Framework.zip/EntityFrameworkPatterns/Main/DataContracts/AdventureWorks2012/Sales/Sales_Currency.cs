// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales
{
    // Currency
    [DataContract]
    public partial class Sales_Currency
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CurrencyCode { get; set; } // CurrencyCode (Primary key). The ISO code for the Currency.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. Currency name.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_CountryRegionCurrency> Sales_CountryRegionCurrency { get; set; } // Many to many mapping
        public virtual ICollection<Sales_CurrencyRate> Sales_CurrencyRate_FromCurrencyCode { get; set; } // CurrencyRate.FK_CurrencyRate_Currency_FromCurrencyCode
        public virtual ICollection<Sales_CurrencyRate> Sales_CurrencyRate_ToCurrencyCode { get; set; } // CurrencyRate.FK_CurrencyRate_Currency_ToCurrencyCode
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_Currency()
        {
            ModifiedDate = System.DateTime.Now;
            Sales_CountryRegionCurrency = new List<Sales_CountryRegionCurrency>();
            Sales_CurrencyRate_FromCurrencyCode = new List<Sales_CurrencyRate>();
            Sales_CurrencyRate_ToCurrencyCode = new List<Sales_CurrencyRate>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
