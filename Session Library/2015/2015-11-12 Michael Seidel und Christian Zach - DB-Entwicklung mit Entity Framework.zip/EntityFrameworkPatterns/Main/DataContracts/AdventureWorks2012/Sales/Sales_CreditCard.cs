// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales
{
    // CreditCard
    [DataContract]
    public partial class Sales_CreditCard
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int CreditCardId { get; set; } // CreditCardID (Primary key). Primary key for CreditCard records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CardType { get; set; } // CardType. Credit card name.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CardNumber { get; set; } // CardNumber. Credit card number.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte ExpMonth { get; set; } // ExpMonth. Credit card expiration month.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short ExpYear { get; set; } // ExpYear. Credit card expiration year.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_PersonCreditCard> Sales_PersonCreditCard { get; set; } // Many to many mapping
        public virtual ICollection<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; } // SalesOrderHeader.FK_SalesOrderHeader_CreditCard_CreditCardID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_CreditCard()
        {
            ModifiedDate = System.DateTime.Now;
            Sales_PersonCreditCard = new List<Sales_PersonCreditCard>();
            Sales_SalesOrderHeader = new List<Sales_SalesOrderHeader>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
