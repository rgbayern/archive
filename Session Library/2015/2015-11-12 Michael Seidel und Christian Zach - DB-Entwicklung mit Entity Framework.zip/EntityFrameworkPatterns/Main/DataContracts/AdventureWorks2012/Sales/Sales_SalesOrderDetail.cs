// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales
{
    // SalesOrderDetail
    [DataContract]
    public partial class Sales_SalesOrderDetail
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int SalesOrderId { get; set; } // SalesOrderID (Primary key). Primary key. Foreign key to SalesOrderHeader.SalesOrderID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int SalesOrderDetailId { get; set; } // SalesOrderDetailID (Primary key). Primary key. One incremental unique number per product sold.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string CarrierTrackingNumber { get; set; } // CarrierTrackingNumber. Shipment tracking number supplied by the shipper.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short OrderQty { get; set; } // OrderQty. Quantity ordered per product.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductId { get; set; } // ProductID. Product sold to customer. Foreign key to Product.ProductID.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int SpecialOfferId { get; set; } // SpecialOfferID. Promotional code. Foreign key to SpecialOffer.SpecialOfferID.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal UnitPrice { get; set; } // UnitPrice. Selling price of a single product.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal UnitPriceDiscount { get; set; } // UnitPriceDiscount. Discount amount.

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal LineTotal { get; internal set; } // LineTotal. Per product subtotal. Computed as UnitPrice * (1 - UnitPriceDiscount) * OrderQty.

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 11, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Foreign keys
        public virtual Sales_SalesOrderHeader Sales_SalesOrderHeader { get; set; } // FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID
        public virtual Sales_SpecialOfferProduct Sales_SpecialOfferProduct { get; set; } // FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_SalesOrderDetail()
        {
            UnitPriceDiscount = 0.0m;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
