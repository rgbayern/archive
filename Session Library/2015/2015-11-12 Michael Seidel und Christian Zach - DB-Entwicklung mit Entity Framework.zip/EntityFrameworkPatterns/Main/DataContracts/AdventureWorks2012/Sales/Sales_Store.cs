// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales
{
    // Store
    [DataContract]
    public partial class Sales_Store
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key. Foreign key to Customer.BusinessEntityID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name. Name of the store.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? SalesPersonId { get; set; } // SalesPersonID. ID of the sales person assigned to the customer. Foreign key to SalesPerson.BusinessEntityID.

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Demographics { get; set; } // Demographics. Demographic informationg about the store such as the number of employees, annual sales and store type.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_Customer> Sales_Customer { get; set; } // Customer.FK_Customer_Store_StoreID

        // Foreign keys
        public virtual Person_BusinessEntity Person_BusinessEntity { get; set; } // FK_Store_BusinessEntity_BusinessEntityID
        public virtual Sales_SalesPerson Sales_SalesPerson { get; set; } // FK_Store_SalesPerson_SalesPersonID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_Store()
        {
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Sales_Customer = new List<Sales_Customer>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
