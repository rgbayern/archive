// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012
{
    public class UspGetBillOfMaterialsReturnModel
    {
        public Int32? ProductAssemblyId { get; set; }
        public Int32? ComponentId { get; set; }
        public String ComponentDesc { get; set; }
        public Decimal? TotalQuantity { get; set; }
        public Decimal? StandardCost { get; set; }
        public Decimal? ListPrice { get; set; }
        public Int16? BomLevel { get; set; }
        public Int32? RecursionLevel { get; set; }
    }

}
