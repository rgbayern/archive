// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Runtime.Serialization;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Person;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Production;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Purchasing;
using EntityFrameworkPatterns.DataContracts.AdventureWorks2012.Sales;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources
{
    // Employee
    [DataContract]
    public partial class HumanResources_Employee
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key for Employee records.  Foreign key to BusinessEntity.BusinessEntityID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string NationalIdNumber { get; set; } // NationalIDNumber. Unique national identification number such as a social security number.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string LoginId { get; set; } // LoginID. Network login.

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string OrganizationNode { get; set; } // OrganizationNode. Where the employee is located in corporate hierarchy.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short? OrganizationLevel { get; internal set; } // OrganizationLevel. The depth of the employee in the corporate hierarchy.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string JobTitle { get; set; } // JobTitle. Work title such as Buyer or Sales Representative.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime BirthDate { get; set; } // BirthDate. Date of birth.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string MaritalStatus { get; set; } // MaritalStatus. M = Married, S = Single

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Gender { get; set; } // Gender. M = Male, F = Female

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime HireDate { get; set; } // HireDate. Employee hired on this date.

        [DataMember(Order = 11, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool SalariedFlag { get; set; } // SalariedFlag. Job classification. 0 = Hourly, not exempt from collective bargaining. 1 = Salaried, exempt from collective bargaining.

        [DataMember(Order = 12, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short VacationHours { get; set; } // VacationHours. Number of available vacation hours.

        [DataMember(Order = 13, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short SickLeaveHours { get; set; } // SickLeaveHours. Number of available sick leave hours.

        [DataMember(Order = 14, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool CurrentFlag { get; set; } // CurrentFlag. 0 = Inactive, 1 = Active

        [DataMember(Order = 15, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 16, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<HumanResources_EmployeeDepartmentHistory> HumanResources_EmployeeDepartmentHistory { get; set; } // Many to many mapping
        public virtual ICollection<HumanResources_EmployeePayHistory> HumanResources_EmployeePayHistory { get; set; } // Many to many mapping
        public virtual ICollection<HumanResources_JobCandidate> HumanResources_JobCandidate { get; set; } // JobCandidate.FK_JobCandidate_Employee_BusinessEntityID
        public virtual ICollection<Production_Document> Production_Document { get; set; } // Document.FK_Document_Employee_Owner
        public virtual ICollection<Purchasing_PurchaseOrderHeader> Purchasing_PurchaseOrderHeader { get; set; } // PurchaseOrderHeader.FK_PurchaseOrderHeader_Employee_EmployeeID
        public virtual Sales_SalesPerson Sales_SalesPerson { get; set; } // SalesPerson.FK_SalesPerson_Employee_BusinessEntityID

        // Foreign keys
        public virtual Person_Person Person_Person { get; set; } // FK_Employee_Person_BusinessEntityID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public HumanResources_Employee()
        {
            SalariedFlag = true;
            VacationHours = 0;
            SickLeaveHours = 0;
            CurrentFlag = true;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Production_Document = new List<Production_Document>();
            HumanResources_EmployeeDepartmentHistory = new List<HumanResources_EmployeeDepartmentHistory>();
            HumanResources_EmployeePayHistory = new List<HumanResources_EmployeePayHistory>();
            HumanResources_JobCandidate = new List<HumanResources_JobCandidate>();
            Purchasing_PurchaseOrderHeader = new List<Purchasing_PurchaseOrderHeader>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
