// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources
{
    // vEmployeeDepartmentHistory
    [DataContract]
    public partial class HumanResources_VEmployeeDepartmentHistory
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Title { get; set; } // Title

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string FirstName { get; set; } // FirstName

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string MiddleName { get; set; } // MiddleName

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string LastName { get; set; } // LastName

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Suffix { get; set; } // Suffix

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Shift { get; set; } // Shift

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Department { get; set; } // Department

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string GroupName { get; set; } // GroupName

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime StartDate { get; set; } // StartDate

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? EndDate { get; set; } // EndDate

    }

}
