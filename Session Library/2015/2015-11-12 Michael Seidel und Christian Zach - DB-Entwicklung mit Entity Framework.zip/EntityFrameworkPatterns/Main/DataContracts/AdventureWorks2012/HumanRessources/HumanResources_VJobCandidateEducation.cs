// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources
{
    // vJobCandidateEducation
    [DataContract]
    public partial class HumanResources_VJobCandidateEducation
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int JobCandidateId { get; set; } // JobCandidateID

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Level { get; set; } // Edu.Level

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? Edu46StartDate { get; set; } // Edu.StartDate

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? Edu46EndDate { get; set; } // Edu.EndDate

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Degree { get; set; } // Edu.Degree

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Major { get; set; } // Edu.Major

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Minor { get; set; } // Edu.Minor

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Gpa { get; set; } // Edu.GPA

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46GpaScale { get; set; } // Edu.GPAScale

        [DataMember(Order = 10, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46School { get; set; } // Edu.School

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Loc46CountryRegion { get; set; } // Edu.Loc.CountryRegion

        [DataMember(Order = 12, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Loc46State { get; set; } // Edu.Loc.State

        [DataMember(Order = 13, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Edu46Loc46City { get; set; } // Edu.Loc.City

    }

}
