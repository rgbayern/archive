// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources
{
    // EmployeeDepartmentHistory
    [DataContract]
    public partial class HumanResources_EmployeeDepartmentHistory
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Employee identification number. Foreign key to Employee.BusinessEntityID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short DepartmentId { get; set; } // DepartmentID (Primary key). Department in which the employee worked including currently. Foreign key to Department.DepartmentID.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte ShiftId { get; set; } // ShiftID (Primary key). Identifies which 8-hour shift the employee works. Foreign key to Shift.Shift.ID.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime StartDate { get; set; } // StartDate (Primary key). Date the employee started work in the department.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? EndDate { get; set; } // EndDate. Date the employee left the department. NULL = Current department.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Foreign keys
        public virtual HumanResources_Department HumanResources_Department { get; set; } // FK_EmployeeDepartmentHistory_Department_DepartmentID
        public virtual HumanResources_Employee HumanResources_Employee { get; set; } // FK_EmployeeDepartmentHistory_Employee_BusinessEntityID
        public virtual HumanResources_Shift HumanResources_Shift { get; set; } // FK_EmployeeDepartmentHistory_Shift_ShiftID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public HumanResources_EmployeeDepartmentHistory()
        {
            ModifiedDate = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
