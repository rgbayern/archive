﻿// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace EntityFrameworkPatterns.DataContracts.AdventureWorks2012.HumanRessources
{
    // JobCandidate
    [DataContract]
    public partial class HumanResources_JobCandidate
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int JobCandidateId { get; set; } // JobCandidateID (Primary key). Primary key for JobCandidate records.

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? BusinessEntityId { get; set; } // BusinessEntityID. Employee identification number if applicant was hired. Foreign key to Employee.BusinessEntityID.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Resume { get; set; } // Resume. Résumé in XML format.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Foreign keys
        public virtual HumanResources_Employee HumanResources_Employee { get; set; } // FK_JobCandidate_Employee_BusinessEntityID
        
        [GeneratedCode("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public HumanResources_JobCandidate()
        {
            ModifiedDate = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
