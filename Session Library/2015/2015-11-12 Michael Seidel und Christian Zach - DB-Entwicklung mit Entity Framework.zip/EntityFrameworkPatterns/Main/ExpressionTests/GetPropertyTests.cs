﻿using System;
using System.Linq.Expressions;
using EntityFrameworkPatterns.Library.CommonExtensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExpressionTests
{
    [TestClass]
    public class GetPropertyTests
    {
        public class Person
        {
            public int Age { get; set; }
        }

        [TestMethod]
        public void GetPropertyNameFromExpressionTest()
        {
            Expression<Func<Person, object>> propertyExpression = person => person.Age;

            var propertyName = propertyExpression.GetPropertyName();

            Assert.AreEqual(propertyName, "Age");
        }

        [TestMethod]
        public void GetPropertyInfoFromExpressionTest()
        {
            Expression<Func<Person, object>> propertyExpression = person => person.Age;

            var myPerson = new Person { Age = 42 };

            var propertyInfo = propertyExpression.GetPropertyInfo();

            var age = propertyInfo.GetValue(myPerson);
            Assert.AreEqual(42, age);

            propertyInfo.SetValue(myPerson, 12);
            Assert.AreEqual(12, myPerson.Age);
        }
    }
}
