﻿namespace EntityFrameworkPatterns.OperationContracts
{
    /// <summary>
    /// Allows objects implementing IModule to register types in unity.
    /// </summary>
    public interface IModuleRegistrar
    {
        void Register<TFrom, TTo>()
            where TFrom : class
            where TTo : class, TFrom;
        void RegisterAsSingleton<TFrom, TTo>()
            where TFrom : class
            where TTo : class, TFrom;
    }
}
