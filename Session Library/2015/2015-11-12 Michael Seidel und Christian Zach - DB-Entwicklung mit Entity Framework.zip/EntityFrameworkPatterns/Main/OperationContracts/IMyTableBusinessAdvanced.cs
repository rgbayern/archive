﻿namespace EntityFrameworkPatterns.OperationContracts
{
    public interface IMyTableBusinessAdvanced : IMyTableBusiness
    {
    }
}
