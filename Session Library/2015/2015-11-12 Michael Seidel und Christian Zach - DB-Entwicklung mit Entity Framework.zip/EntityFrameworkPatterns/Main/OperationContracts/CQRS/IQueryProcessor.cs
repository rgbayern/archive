﻿namespace EntityFrameworkPatterns.OperationContracts.CQRS
{
    public interface IQueryProcessor
    {
        TResult Process<TResult>(IQuery<TResult> query);
    }

    // Alternative zur Vermeidung von dynamic in der Implementierung

    //public interface IQueryProcessor
    //{
    //    TResult Process<TQuery, TResult>(TQuery query) where TQuery : IQuery<TResult>;
    //}
}
