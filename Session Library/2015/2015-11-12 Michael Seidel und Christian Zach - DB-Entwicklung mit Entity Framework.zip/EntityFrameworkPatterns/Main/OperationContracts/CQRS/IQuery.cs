﻿namespace EntityFrameworkPatterns.OperationContracts.CQRS
{
    public interface IQuery<TResult>
    {
    }
}
