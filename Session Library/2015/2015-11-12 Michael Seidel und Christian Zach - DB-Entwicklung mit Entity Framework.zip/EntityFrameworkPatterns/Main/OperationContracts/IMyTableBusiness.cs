﻿using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace EntityFrameworkPatterns.OperationContracts
{
    public interface IMyTableBusiness
    {
        MyTable[] UseTheQuery();
        MyTable UseTheFirstOrDefaultQuery();
    }
}
