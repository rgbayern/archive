﻿using System.Collections.Generic;
using EntityFrameworkPatterns.Contexts.DemoDatabaseContext;

namespace EntityFrameworkPatterns.OperationContracts
{
    public interface IDemoDatabaseAccessForConsole
    {
        int Add(MyTable data);
        IEnumerable<MyTable> GetAllItems();
    }
}
