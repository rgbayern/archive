﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace EntityFrameworkPatterns.Library.CommonExtensions
{
    /// <summary>
    /// Predicate Expression Extensions 
    /// </summary>
    public static class PredicateExpressionExtensions
    {
        /// <summary>
        /// Results in: first predicate AND second predicate.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first">The first.</param>
        /// <param name="second">The second.</param>
        /// <returns></returns>
        public static Expression<Func<T, bool>> And<T>(this Expression<Func<T, bool>> first, Expression<Func<T, bool>> second)
        {
            return first.Compose(second, Expression.And);
        }

        /// <summary>
        /// Results in: first predicate OR second predicate.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first">The first.</param>
        /// <param name="second">The second.</param>
        /// <returns></returns>
        public static Expression<Func<T, bool>> Or<T>(this Expression<Func<T, bool>> first, Expression<Func<T, bool>> second)
        {
            return first.Compose(second, Expression.Or);
        }

        #region Private Methods
        /// <summary>
        /// Composes the specified second.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first">The first.</param>
        /// <param name="second">The second.</param>
        /// <param name="mergeFunc">The merge function.</param>
        /// <returns></returns>
        private static Expression<T> Compose<T>(this Expression<T> first, Expression<T> second, Func<Expression, Expression, Expression> mergeFunc)
        {
            var parameterMapping = first.Parameters
                .Select((parameterExpression, index) => new { first = parameterExpression, second = second.Parameters[index] })
                .ToDictionary(p => p.second, p => p.first);
            var secondBody = ParameterRebinder.ReplaceParameters(parameterMapping, second.Body);
            return Expression.Lambda<T>(mergeFunc(first.Body, secondBody), first.Parameters);
        }

        /// <summary>
        /// ExpressionVisitor to replace the parameters in an Expression with the parameters of another.
        /// </summary>
        private class ParameterRebinder : ExpressionVisitor
        {
            /// <summary>
            /// Replaces the parameters.
            /// </summary>
            /// <param name="map">The parameterExpressionMapping.</param>
            /// <param name="exp">The exp.</param>
            /// <returns></returns>
            public static Expression ReplaceParameters(Dictionary<ParameterExpression, ParameterExpression> map, Expression exp)
            {
                return new ParameterRebinder(map).Visit(exp);
            }

            /// <summary>
            /// Key is the parameter of the second expression, value the parameter of the first (target).
            /// </summary>
            private readonly Dictionary<ParameterExpression, ParameterExpression> _parameterExpressionMapping;

            /// <summary>
            /// Initializes a new instance of the <see cref="ParameterRebinder"/> class.
            /// </summary>
            /// <param name="parameterExpressionMapping">The parameterExpressionMapping.</param>
            private ParameterRebinder(Dictionary<ParameterExpression, ParameterExpression> parameterExpressionMapping)
            {
                _parameterExpressionMapping = parameterExpressionMapping ?? new Dictionary<ParameterExpression, ParameterExpression>();
            }

            /// <summary>
            /// Visits the parameter.
            /// </summary>
            /// <param name="parameter">The parameter.</param>
            /// <returns></returns>
            protected override Expression VisitParameter(ParameterExpression parameter)
            {
                ParameterExpression replacement;
                if (_parameterExpressionMapping.TryGetValue(parameter, out replacement)) parameter = replacement;
                return base.VisitParameter(parameter);
            }
        } 
        #endregion
    }
}
