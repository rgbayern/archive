﻿using System;
using System.Linq.Expressions;
using System.Reflection;

namespace EntityFrameworkPatterns.Library.CommonExtensions
{
    public static class PropertyExpressionExtensions
    {
        /// <summary>
        /// Die Expression "person => person.Name" führt zum Ergebnis "Name". Es wird also typsicher der Name einer Property übergeben.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>     
        /// <remarks>
        /// Properties mit primitivem Datentyp werden implizit als Operand einer UnaryExpression gekapselt, 
        /// d.h. aus "x => x.Zahl" wird "x => Convert(x.Zahl)" allein durch den Aufruf.
        /// </remarks>
        public static string GetPropertyName<T>(this Expression<Func<T, object>> expression)
        {
            var propertyName = (expression.Body as MemberExpression ?? (MemberExpression)((UnaryExpression)expression.Body).Operand).Member.Name;
            return propertyName;
        }

        /// <summary>
        /// Aus einer Expression wird die zugehörige PropertyInfo ermittelt.
        /// </summary>
        /// <typeparam name="T">Typ</typeparam>
        /// <param name="expression">Identifiziert eine Property</param>
        /// <returns></returns>
        public static PropertyInfo GetPropertyInfo<T>(this Expression<Func<T, object>> expression)
        {
            var propertyName = expression.GetPropertyName();
            return typeof(T).GetProperty(propertyName);
        }
    }
}
