﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using EntityFrameworkPatterns.Library.CommonClasses;

namespace EntityFrameworkPatterns.Library.CommonExtensions
{
    /// <summary>
    /// Erweiterungen für IQueryable
    /// </summary>
    public static class QueryableExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <param name="query">The query.</param>
        /// <param name="keyItems">The key items.</param>
        /// <param name="keyExpression">The key expression.</param>
        /// <returns></returns>
        public static IQueryable<T> WhereIn<T, TKey>(this IQueryable<T> query, IEnumerable<TKey> keyItems, Expression<Func<T, object>> keyExpression)
            where T : class, new()
        {
            var parameterExpression = Expression.Parameter(typeof(T), "item");

            var bodyExpression = keyItems
                .Select(x => Expression.Equal(
                    Expression.MakeMemberAccess(parameterExpression, keyExpression.GetPropertyInfo()),
                    Expression.Constant(x)))
                .Aggregate(Expression.Or);

            var predicate = Expression.Lambda<Func<T, bool>>(bodyExpression, parameterExpression);
            return query.Where(predicate);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query">The query.</param>
        /// <param name="whereInParam">The where in parameter.</param>
        /// <returns></returns>
        public static IQueryable<T> WhereIn<T>(this IQueryable<T> query, WhereInParam<T> whereInParam)
            where T : class, new()
        {
            var parameterExpression = Expression.Parameter(typeof(T), "item");

            var bodyExpression = whereInParam.KeyItems
                .Select(x => whereInParam.KeyPropertyExpressions
                    .Select(keyPropertyExpression => Expression.Equal(
                        Expression.MakeMemberAccess(parameterExpression, keyPropertyExpression.GetPropertyInfo()),
                        Expression.Constant(keyPropertyExpression.Compile()(x))))
                    .Aggregate(Expression.And))
                    .Aggregate(Expression.Or);

            var predicate = Expression.Lambda<Func<T, bool>>(bodyExpression, parameterExpression);
            return query.Where(predicate);
        }

        /// <summary>
        /// Left Join
        /// </summary>
        /// <typeparam name="TOuter">The type of the outer.</typeparam>
        /// <typeparam name="TInner">The type of the inner.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="outer">The outer.</param>
        /// <param name="inner">The inner.</param>
        /// <param name="outerKeySelector">The outer key selector.</param>
        /// <param name="innerKeySelector">The inner key selector.</param>
        /// <param name="resultSelector">The result selector.</param>
        /// <returns></returns>
        public static IQueryable<TResult> QueryLeftJoin<TOuter, TInner, TKey, TResult>(this IQueryable<TOuter> outer,
            IQueryable<TInner> inner,
            Expression<Func<TOuter, TKey>> outerKeySelector,
            Expression<Func<TInner, TKey>> innerKeySelector,
            Expression<Func<TOuter, TInner, TResult>> resultSelector)
        {
            var select = typeof(Queryable).GetMethods().First(x => x.Name == "Select" && x.GetParameters().Length == 2);
            var selectMany = typeof(Queryable).GetMethods().Where(x => x.Name == "SelectMany" && x.GetParameters().Length == 3).OrderBy(x => x.ToString().Length).First();
            var groupJoin = typeof(Queryable).GetMethods().First(x => x.Name == "GroupJoin" && x.GetParameters().Length == 5);
            var defaultIfEmpty = typeof(Queryable).GetMethods().First(x => x.Name == "DefaultIfEmpty" && x.GetParameters().Length == 1);
            var where = typeof(Queryable).GetMethods().First(x => x.Name == "Where" && x.GetParameters().Length == 2);

            var resultOfStep1 = typeof(Tuple<,>).MakeGenericType(typeof(TOuter), typeof(IQueryable<>).MakeGenericType(typeof(TInner)));
            var paramOuter = Expression.Parameter(typeof(TOuter));
            var paramInner = Expression.Parameter(typeof(IEnumerable<TInner>));

            var groupJoinExpression = Expression.Call(null, groupJoin.MakeGenericMethod(typeof(TOuter), typeof(TInner), typeof(TKey), resultOfStep1),
                Expression.Constant(outer), Expression.Constant(inner), outerKeySelector, innerKeySelector,
                Expression.Lambda(Expression.New(resultOfStep1.GetConstructor(resultOfStep1.GetGenericArguments()),
                    new Expression[] { paramOuter, Expression.Call(null, defaultIfEmpty.MakeGenericMethod(typeof(TInner)), Expression.Convert(paramInner, typeof(IQueryable<TInner>))) },
                    resultOfStep1.GetProperties()
                ), paramOuter, paramInner));

            var resultOfStep2 = typeof(Tuple<,>).MakeGenericType(typeof(TOuter), typeof(TInner));
            var paramTuple2 = Expression.Parameter(resultOfStep1);
            var paramInner2 = Expression.Parameter(typeof(TInner));
            var paramGroup = Expression.Parameter(resultOfStep1);

            var selectMany1Result = Expression.Call(null, selectMany.MakeGenericMethod(resultOfStep1, typeof(TInner), resultOfStep2),
                new Expression[]
                {
                    groupJoinExpression,
                    Expression.Lambda(Expression.Convert(Expression.MakeMemberAccess(paramGroup, resultOfStep1.GetProperty("Item2")),typeof (IEnumerable<TInner>)),paramGroup),
                    Expression.Lambda(Expression.New(resultOfStep2.GetConstructor(resultOfStep2.GetGenericArguments()),
                        new Expression[]{Expression.MakeMemberAccess(paramTuple2, paramTuple2.Type.GetProperty("Item1")),paramInner2},
                        resultOfStep2.GetProperties()),
                        paramTuple2, paramInner2)
                });

            var paramTuple3 = Expression.Parameter(resultOfStep2);
            var paramTuple4 = Expression.Parameter(resultOfStep2);
            var paramOuter3 = Expression.Parameter(typeof(TOuter));
            var selectManyResult2 = selectMany
                .MakeGenericMethod(typeof(TOuter), typeof(TInner), typeof(TResult))
                .Invoke(null, new object[]
                {
                    outer,
                    Expression.Lambda(Expression.Convert(Expression.Call(null,select.MakeGenericMethod(resultOfStep2, typeof(TInner)),
                        new Expression[]
                        {
                            Expression.Call(null,where.MakeGenericMethod(resultOfStep2),
                                new Expression[]
                                {
                                    selectMany1Result,
                                    Expression.Lambda(Expression.Equal(paramOuter3,Expression.MakeMemberAccess(paramTuple4, paramTuple4.Type.GetProperty("Item1"))),
                                    paramTuple4)
                                }),
                            Expression.Lambda(Expression.MakeMemberAccess(paramTuple3, paramTuple3.Type.GetProperty("Item2")),paramTuple3)
                        }),
                    typeof(IEnumerable<TInner>)),paramOuter3),
                    resultSelector
                }
            );

            return (IQueryable<TResult>)selectManyResult2;
        }
    }
}
