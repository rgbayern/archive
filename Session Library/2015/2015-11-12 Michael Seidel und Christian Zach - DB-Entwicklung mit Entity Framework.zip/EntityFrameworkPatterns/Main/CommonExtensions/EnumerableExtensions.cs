﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using EntityFrameworkPatterns.Library.CommonClasses;

namespace EntityFrameworkPatterns.Library.CommonExtensions
{
    /// <summary>
    /// Extension methods for the Enumerable class
    /// </summary>
    public static class EnumerableExtensions
    {
        #region AsKeysIn
        /// <summary>
        /// Helper for IQueryableExtensions.WhereIn
        /// </summary>
        /// <typeparam name="TTarget">The type of the target.</typeparam>
        /// <param name="keyItems">The key items.</param>
        /// <returns></returns>
        public static WhereInParam<TTarget> AsKeysIn<TTarget>(this IEnumerable<object> keyItems)
            where TTarget : class, new()
        {
            var enumerable = keyItems as object[] ?? keyItems.ToArray();
            var keyProperties = enumerable.First().GetType().GetProperties().ToList();

            return new WhereInParam<TTarget>
            {
                KeyItems = enumerable.Select(item => CreateKeyItem<TTarget>(item, keyProperties)),
                KeyPropertyExpressions = keyProperties.Select(CreateKeyExpression<TTarget>).ToArray()
            };
        }

        /// <summary>
        /// Creates the key expression.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="propertyInfo">The property information.</param>
        /// <returns></returns>
        private static Expression<Func<T, object>> CreateKeyExpression<T>(PropertyInfo propertyInfo)
        {
            var param = Expression.Parameter(typeof(T));
            var field = Expression.Convert(Expression.PropertyOrField(param, propertyInfo.Name), typeof(object));
            return Expression.Lambda<Func<T, object>>(field, param);
        }

        /// <summary>
        /// Creates the key item.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item">The item.</param>
        /// <param name="keyProperties">The key properties.</param>
        /// <returns></returns>
        private static T CreateKeyItem<T>(object item, IEnumerable<PropertyInfo> keyProperties)
            where T : class, new()
        {
            var result = new T();
            var targetKeyProperties = keyProperties.Join(typeof(T).GetProperties(), x => x.Name, y => y.Name, (x, y) => new { x, y }).ToList();
            targetKeyProperties.ForEach(prop => prop.y.SetValue(result, prop.x.GetValue(item)));
            return result;
        }
        #endregion

        #region Fragment
        /// <summary>
        /// Fragments the enumeration into FragmentItems containing fragmentSize items each.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="enumerable">The enumerable.</param>
        /// <param name="fragmentSize">Size of the fragment.</param>
        /// <returns></returns>
        public static IEnumerable<KeyValuePair<int, IEnumerable<T>>> Fragment<T>(this IEnumerable<T> enumerable, int fragmentSize)
        {
            return enumerable
                .Select((x, i) => new { Item = x, Index = i })
                .GroupBy(pair => pair.Index / fragmentSize, (k, v) => new KeyValuePair<int, IEnumerable<T>>(k, v.Select(x => x.Item)));
        }

        #endregion

        #region In-Memory Joins

        /// <summary>
        /// All left with matching right or default.
        /// </summary>
        /// <typeparam name="TLeft">The type of the left.</typeparam>
        /// <typeparam name="TRight">The type of the right.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the resultSelector.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The leftKey.</param>
        /// <param name="rightKey">The rightKey.</param>
        /// <param name="resultSelector">The resultSelector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> LeftJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                 IEnumerable<TRight> rights,
                                                                                 Func<TLeft, TKey> leftKey,
                                                                                 Func<TRight, TKey> rightKey,
                                                                                 Func<TLeft, TRight, TResult> resultSelector)
        {
            return lefts
                .GroupJoin(rights, leftKey, rightKey, (left, matchingRights) => matchingRights.Select(right => resultSelector(left, right)).DefaultIfEmpty(resultSelector(left, default(TRight))))
                .SelectMany(x => { var enumerable = x as TResult[] ?? x.ToArray(); return enumerable; });
        }

        /// <summary>
        /// All right with matching left or default.
        /// </summary>
        /// <typeparam name="TLeft">The type of the left.</typeparam>
        /// <typeparam name="TRight">The type of the right.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the resultSelector.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The leftKey.</param>
        /// <param name="rightKey">The rightKey.</param>
        /// <param name="resultSelector">The resultSelector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> RightJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                 IEnumerable<TRight> rights,
                                                                                 Func<TLeft, TKey> leftKey,
                                                                                 Func<TRight, TKey> rightKey,
                                                                                 Func<TLeft, TRight, TResult> resultSelector)
        {
            return rights
                .GroupJoin(lefts, rightKey, leftKey, (right, matchingLefts) => matchingLefts.Select(left => resultSelector(left, right)).DefaultIfEmpty(resultSelector(default(TLeft), right)))
                .SelectMany(x => { var enumerable = x as TResult[] ?? x.ToArray(); return enumerable; });
        }

        /// <summary>
        /// Union of left and right join.
        /// </summary>
        /// <typeparam name="TLeft">The type of the left.</typeparam>
        /// <typeparam name="TRight">The type of the right.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the resultSelector.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The leftKey.</param>
        /// <param name="rightKey">The rightKey.</param>
        /// <param name="resultSelector">The resultSelector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> FullOuterJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                         IEnumerable<TRight> rights,
                                                                                         Func<TLeft, TKey> leftKey,
                                                                                         Func<TRight, TKey> rightKey,
                                                                                         Func<TLeft, TRight, TResult> resultSelector)
        {
            var leftArray = lefts as TLeft[] ?? lefts.ToArray();
            var rightArray = rights as TRight[] ?? rights.ToArray();

            var left = leftArray.LeftJoin(rightArray, leftKey, rightKey, resultSelector).ToArray();
            var right = leftArray.RightJoin(rightArray, leftKey, rightKey, resultSelector).ToArray();

            return left.Union(right);
        }

        /// <summary>
        /// All left except those with a matching right.
        /// </summary>
        /// <typeparam name="TLeft">The type of the left.</typeparam>
        /// <typeparam name="TRight">The type of the child.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The left key.</param>
        /// <param name="rightKey">The right key.</param>
        /// <param name="resultSelector">The result selector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> LeftExcludingJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                         IEnumerable<TRight> rights,
                                                                                         Func<TLeft, TKey> leftKey,
                                                                                         Func<TRight, TKey> rightKey,
                                                                                         Func<TLeft, TRight, TResult> resultSelector)
        {
            return from left in lefts
                   join right in rights
                   on leftKey(left) equals rightKey(right) into joinData
                   from right in joinData.DefaultIfEmpty(default(TRight))
                   where Equals(right, default(TRight))
                   select resultSelector(left, right);
        }

        /// <summary>
        /// All right except those without matching left.
        /// </summary>
        /// <typeparam name="TLeft">The type of the left.</typeparam>
        /// <typeparam name="TRight">The type of the child.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The left key.</param>
        /// <param name="rightKey">The right key.</param>
        /// <param name="resultSelector">The result selector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> RightExcludingJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                         IEnumerable<TRight> rights,
                                                                                         Func<TLeft, TKey> leftKey,
                                                                                         Func<TRight, TKey> rightKey,
                                                                                         Func<TLeft, TRight, TResult> resultSelector)
        {
            return from right in rights
                   join left in lefts
                   on rightKey(right) equals leftKey(left) into joinData
                   from left in joinData.DefaultIfEmpty(default(TLeft))
                   where Equals(left, default(TLeft))
                   select resultSelector(left, right);
        }

        /// <summary>
        /// Union of all left and right that do not have a matching partner.
        /// </summary>
        /// <typeparam name="TLeft">The type of the source.</typeparam>
        /// <typeparam name="TRight">The type of the child.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="lefts">The left.</param>
        /// <param name="rights">The right.</param>
        /// <param name="leftKey">The left key.</param>
        /// <param name="rightKey">The right key.</param>
        /// <param name="resultSelector">The result selector.</param>
        /// <returns></returns>
        public static IEnumerable<TResult> OuterExcludingJoin<TLeft, TRight, TKey, TResult>(this IEnumerable<TLeft> lefts,
                                                                                         IEnumerable<TRight> rights,
                                                                                         Func<TLeft, TKey> leftKey,
                                                                                         Func<TRight, TKey> rightKey,
                                                                                         Func<TLeft, TRight, TResult> resultSelector)
        {
            var leftArray = lefts as TLeft[] ?? lefts.ToArray();
            var rightArray = rights as TRight[] ?? rights.ToArray();

            var leftExcludingJoin = leftArray.LeftExcludingJoin(rightArray, leftKey, rightKey, resultSelector).ToArray();
            var rightExcludingJoin = leftArray.RightExcludingJoin(rightArray, leftKey, rightKey, resultSelector).ToArray();

            return leftExcludingJoin.Union(rightExcludingJoin);
        }

        #endregion
    }
}
