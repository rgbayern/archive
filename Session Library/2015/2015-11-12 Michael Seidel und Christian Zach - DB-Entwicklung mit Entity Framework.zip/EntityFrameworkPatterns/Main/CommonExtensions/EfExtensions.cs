﻿using System;
using System.Data.Entity;

namespace EntityFrameworkPatterns.Library.CommonExtensions
{
    public static class EfExtensions
    {
        /// <summary>
        /// Zwei Regeln sind beim Deaktivieren von AutoDetectChangesEnabled zu beachten:
        /// 
        /// 1. No call to EF code will leave the context in a state where DetectChanges needs to be called if it didn’t need to be called before.
        /// 2. Any time that non-EF code changes any property value of an entity or complex object then DetectChanges may need to be called.
        /// 
        /// Quelle: http://blog.oneunicorn.com/2012/03/12/secrets-of-detectchanges-part-3-switching-off-automatic-detectchanges/
        /// </summary>
        /// <typeparam name="TTable"></typeparam>
        /// <param name="context"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public static DbContext DoUndetected<TTable>(this DbContext context, Action<DbContext> action)
            where TTable : class
        {
            try
            {
                context.Configuration.AutoDetectChangesEnabled = false;
                action(context);
            }
            finally
            {
                context.Configuration.AutoDetectChangesEnabled = true;
            }
            return context;
        }

        public static DbContext DoWithSingleDetection<TTable>(this DbContext context, Action<DbContext> action)
            where TTable : class
        {
            try
            {
                context.Configuration.AutoDetectChangesEnabled = false;
                action(context);
            }
            finally
            {
                context.ChangeTracker.DetectChanges();
                context.Configuration.AutoDetectChangesEnabled = true;
            }
            return context;
        }
    }
}
