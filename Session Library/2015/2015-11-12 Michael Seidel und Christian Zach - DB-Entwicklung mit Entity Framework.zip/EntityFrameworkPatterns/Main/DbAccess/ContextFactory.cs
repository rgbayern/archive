﻿using System;
using System.Data.Entity;
using System.Diagnostics;

namespace EntityFrameworkPatterns.Components.DbAccess_
{
    /// <summary>
    /// Erweiterbare Standardimplementierung von IContextFactory zum Erstellen von Kontexten.
    /// </summary>
    public class ContextFactory : IContextFactory
    {
        // Abhängigkeit von Verbindungsinformationen
        private readonly IConnectionInfo _connectionInfo;

        // Wird verwendet, wenn gesetzt
        protected Action<string> LogAction { get; set; }

        private static void WriteToDebugAndConsole(string text)
        {
            Console.Write(text);
            Debug.Print(text);
        }

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="connectionInfo">Übergabe der Verbindungsinformationen per contructor injection</param>
        public ContextFactory(IConnectionInfo connectionInfo)
        {
            _connectionInfo = connectionInfo;
            LogAction = WriteToDebugAndConsole;
        }

        /// <summary>
        /// Erzeugt einen konfigurierten Kontext vom angegebenen Typ für rein lesende Zugriffe.
        /// </summary>
        /// <typeparam name="TContext">Der zu erzeugende Kontexttyp</typeparam>
        /// <returns></returns>
        public TContext CreateNonTrackingContext<TContext>()
            where TContext : DbContext, new()
        {
            var context = CreateBaseContext<TContext>();
            DisableTracking(context);
            return context;
        }

        /// <summary>
        /// Erzeugt einen konfigurierten Kontext vom angegebenen Typ für lesende und schreibende Zugriffe.
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <returns></returns>
        public TContext CreateTrackingContext<TContext>()
            where TContext : DbContext, new()
        {
            var context = CreateBaseContext<TContext>();
            return context;
        }

        /// <summary>
        /// Erzeugt eine Kontextinstanz mit einer Basiskonfiguration.
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <returns></returns>
        /// <remarks>Ohne besondere Zuweisung wird der ConnectionString aus der app.config verwendet.</remarks>
        private TContext CreateBaseContext<TContext>() where TContext : DbContext, new()
        {
            var context = CreateContextInstance<TContext>();
            context.Database.Connection.ConnectionString = _connectionInfo.ConnectionString;
            if (LogAction != null) context.Database.Log = LogAction;
            return context;
        }

        /// <summary>
        /// Überschreibbar zur Verwendung alternativer Kontextinstanzen (z.B. für Mocks in Tests)
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <returns></returns>
        protected virtual TContext CreateContextInstance<TContext>()
            where TContext : DbContext, new()
        {
            return new TContext();
        }

        /// <summary>
        /// Erhöht die Performance für rein lesende Zugriffe auf Kontextebene.
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <param name="context"></param>
        /// <remarks>
        /// Ab ca. 100 Einträgen im Kontext sind überhaupt Unterschiede vorhanden. 
        /// Es ist dringend empfohlen, bei Schreibzugriffen nur eingeschränkt und wenn, dann sehr bewusst das Tracking zu deaktivieren.
        /// Siehe dazu auch "EfExtensions.DoUndetected"
        /// </remarks>
        private static void DisableTracking<TContext>(TContext context)
            where TContext : DbContext
        {
            // http://blog.oneunicorn.com/2012/03/10/secrets-of-detectchanges-part-1-what-does-detectchanges-do/
            // http://blog.oneunicorn.com/2012/03/11/secrets-of-detectchanges-part-2-when-is-detectchanges-called-automatically/
            // http://blog.oneunicorn.com/2012/03/12/secrets-of-detectchanges-part-3-switching-off-automatic-detectchanges/
            // http://blog.oneunicorn.com/2012/03/13/secrets-of-detectchanges-part-4-binary-properties-and-complex-types/

            // Deaktivieren der DetectChanges Aufrufe auf Kontextebene.
            context.Configuration.AutoDetectChangesEnabled = false;

            // Proxies werden für change tracking und lazy loading verwendet.
            // false -> kein tracking, kein lazy loading
            // true  -> tracking, lazy loading abhängig von der weiteren Einstellung
            context.Configuration.ProxyCreationEnabled = false;

            // context.Configuration.LazyLoadingEnabled = false;
        }
    }
}
