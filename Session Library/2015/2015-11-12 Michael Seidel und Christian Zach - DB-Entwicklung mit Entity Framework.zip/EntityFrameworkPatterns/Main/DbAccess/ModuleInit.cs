﻿using System.ComponentModel.Composition;
using EntityFrameworkPatterns.OperationContracts;

namespace EntityFrameworkPatterns.Components.DbAccess_
{
    [Export(typeof(IModule))]
    public class ModuleInit : IModule
    {
        public void Initialize(IModuleRegistrar registrar)
        {
            registrar.RegisterAsSingleton<IConnectionInfo, ConnectionInfo>();
            registrar.RegisterAsSingleton<IContextFactory, ContextFactory>();
        }
    }
}
