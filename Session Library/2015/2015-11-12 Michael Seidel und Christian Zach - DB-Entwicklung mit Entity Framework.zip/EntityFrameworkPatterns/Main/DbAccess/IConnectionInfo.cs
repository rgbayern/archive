﻿namespace EntityFrameworkPatterns.Components.DbAccess_
{
    public interface IConnectionInfo
    {
        string ConnectionString { get; }
    }
}