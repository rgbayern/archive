﻿using System.Data.SqlClient;

namespace EntityFrameworkPatterns.Components.DbAccess_
{
    /// <summary>
    /// Abstraktion einer Verbindungszeichenfolge
    /// </summary>
    public class ConnectionInfo : IConnectionInfo
    {
        public ConnectionInfo()
        {
            ConnectionString = new SqlConnectionStringBuilder { IntegratedSecurity = true, DataSource = @"CODEPAD\SQLEXPRESS", InitialCatalog = "DemoContext" }.ConnectionString;
        }

        public string ConnectionString { get; }
    }
}
