﻿using System.Data.Entity;

namespace EntityFrameworkPatterns.Components.DbAccess_
{
    /// <summary>
    /// Abstraktion einer Factory zum Erzeugen von Kontexten.
    /// </summary>
    /// <remarks>Hiermit werden Abhängigkeiten von Klassen beschrieben, die Kontexte erzeugen.</remarks>
    public interface IContextFactory
    {
        T CreateNonTrackingContext<T>() where T : DbContext, new();
        T CreateTrackingContext<T>() where T : DbContext, new();
    }
}