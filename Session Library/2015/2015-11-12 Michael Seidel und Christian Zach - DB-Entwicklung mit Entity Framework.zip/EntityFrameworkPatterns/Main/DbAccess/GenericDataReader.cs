﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace EntityFrameworkPatterns.Components.DbAccess_
{
    public class GenericDataReader<TContext, TTable>
        where TContext : DbContext, new()
        where TTable : class
    {
        protected readonly IContextFactory ContextFactory;

        public GenericDataReader(IContextFactory contextFactory)
        {
            ContextFactory = contextFactory;
        }

        /// <summary>
        /// Ungefiltert die komplette Tabelle abfragen. 
        /// </summary>
        /// <returns></returns>
        public List<TTable> GetAll()
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                return context.Set<TTable>().AsNoTracking().ToList();
            }
        }

        /// <summary>
        /// Abfrage mit Filter.
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public List<TTable> GetList(Expression<Func<TTable, bool>> predicate)
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                return context.Set<TTable>().Where(predicate).ToList();
            }
        }

        /// <summary>
        /// Abfrage mit Filter und Projektion auf die gewünschten Dimensionen.
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="predicate"></param>
        /// <param name="resultSelector"></param>
        /// <returns></returns>
        public List<TResult> GetList<TResult>(Expression<Func<TTable, bool>> predicate, Expression<Func<TTable, TResult>> resultSelector)
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                return context.Set<TTable>().Where(predicate).Select(resultSelector).ToList();
            }
        }

        /// <summary>
        ///  Abfrage mit Filter und Projektion für einen implizit verknüpften Tabellenverbund
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="predicate"></param>
        /// <param name="resultSelector"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        public List<TResult> GetList<TResult>(Expression<Func<TTable, bool>> predicate,
            Expression<Func<TTable, TResult>> resultSelector,
            params Expression<Func<TTable, object>>[] includes)
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                var tableWithIncludes = includes != null && includes.Any()
                    ? includes.Aggregate(context.Set<TTable>().AsQueryable(),
                        (current, toInclude) => current.Include(toInclude))
                    : context.Set<TTable>();
                return tableWithIncludes.Where(predicate).Select(resultSelector).ToList();
            }
        }

        public TResult GetFirst<TResult>(Expression<Func<TTable, bool>> predicate, Expression<Func<TTable, TResult>> resultSelector)
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                return context.Set<TTable>().Where(predicate).Select(resultSelector).First();
            }
        }

        public List<TResult> GetTop<TResult>(Expression<Func<TTable, bool>> predicate, Expression<Func<TTable, TResult>> resultSelector, int numberOfResults)
        {
            using (var context = ContextFactory.CreateNonTrackingContext<TContext>())
            {
                return context.Set<TTable>().Where(predicate).Select(resultSelector).Take(numberOfResults).ToList();
            }
        }
    }
}
