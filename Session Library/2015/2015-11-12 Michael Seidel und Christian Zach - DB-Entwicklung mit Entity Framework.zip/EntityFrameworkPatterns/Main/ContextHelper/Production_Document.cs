// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // Document
    [DataContract]
    public partial class Production_Document
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string DocumentNode { get; set; } // DocumentNode (Primary key). Primary key for Document records.

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public short? DocumentLevel { get; internal set; } // DocumentLevel. Depth in the document hierarchy.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Title { get; set; } // Title. Title of the document.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int Owner { get; set; } // Owner. Employee who controls the document.  Foreign key to Employee.BusinessEntityID

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool FolderFlag { get; set; } // FolderFlag. 0 = This is a folder, 1 = This is a document.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string FileName { get; set; } // FileName. File name of the document

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string FileExtension { get; set; } // FileExtension. File extension indicating the document type. For example, .doc or .txt.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Revision { get; set; } // Revision. Revision number of the document.

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ChangeNumber { get; set; } // ChangeNumber. Engineering change approval number.

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte Status { get; set; } // Status. 1 = Pending approval, 2 = Approved, 3 = Obsolete

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string DocumentSummary { get; set; } // DocumentSummary. Document abstract.

        [DataMember(Order = 12, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public byte[] Document { get; set; } // Document. Complete document.

        [DataMember(Order = 13, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Required for FileStream.

        [DataMember(Order = 14, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Production_ProductDocument> Production_ProductDocument { get; set; } // Many to many mapping

        // Foreign keys
        public virtual HumanResources_Employee HumanResources_Employee { get; set; } // FK_Document_Employee_Owner
        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_Document()
        {
            FolderFlag = false;
            ChangeNumber = 0;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Production_ProductDocument = new List<Production_ProductDocument>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
