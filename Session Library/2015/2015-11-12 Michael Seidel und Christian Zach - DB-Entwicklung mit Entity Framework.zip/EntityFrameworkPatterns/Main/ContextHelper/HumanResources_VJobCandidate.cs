// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // vJobCandidate
    [DataContract]
    public partial class HumanResources_VJobCandidate
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int JobCandidateId { get; set; } // JobCandidateID

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? BusinessEntityId { get; set; } // BusinessEntityID

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name46Prefix { get; set; } // Name.Prefix

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name46First { get; set; } // Name.First

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name46Middle { get; set; } // Name.Middle

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name46Last { get; set; } // Name.Last

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name46Suffix { get; set; } // Name.Suffix

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Skills { get; set; } // Skills

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Addr46Type { get; set; } // Addr.Type

        [DataMember(Order = 10, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Addr46Loc46CountryRegion { get; set; } // Addr.Loc.CountryRegion

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Addr46Loc46State { get; set; } // Addr.Loc.State

        [DataMember(Order = 12, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Addr46Loc46City { get; set; } // Addr.Loc.City

        [DataMember(Order = 13, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Addr46PostalCode { get; set; } // Addr.PostalCode

        [DataMember(Order = 14, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string EMail { get; set; } // EMail

        [DataMember(Order = 15, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string WebSite { get; set; } // WebSite

        [DataMember(Order = 16, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate

    }

}
