﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using Moq;

namespace EntityFrameworkPatterns.ContextHelper
{
    public static class EfMoqTools
    {
        public class MockedDbContext<T> : Mock<T>
            where T : DbContext
        {
            private Dictionary<string, object> _tables;
            public Dictionary<string, object> Tables => _tables ?? (_tables = new Dictionary<string, object>());
        }

        /// <summary>
        /// Erzeugt vom angegebenen Typ einen Mock
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <returns></returns>
        public static MockedDbContext<TContext> CreateMockedDbContext<TContext>()
            where TContext : DbContext
        {
            var mockedDbContext = new MockedDbContext<TContext>();
            MockTables(mockedDbContext);
            mockedDbContext.Setup(x => x.SaveChanges()).Verifiable();
            return mockedDbContext;
        }

        private static void MockTables<T>(this MockedDbContext<T> mockedContext)
            where T : DbContext
        {
            var contextType = typeof(T);
            var dbSetProperties = contextType.GetProperties()
                .Where(prop => (prop.PropertyType.IsGenericType)
                && prop.PropertyType.GetGenericTypeDefinition() == typeof(DbSet<>));
            foreach (var propertyInfo in dbSetProperties)
            {
                var dbSetGenericType = propertyInfo.PropertyType.GetGenericArguments()[0];
                var listType = typeof(List<>).MakeGenericType(dbSetGenericType);
                var listForFakeTable = Activator.CreateInstance(listType);

                // Mocken der context."Property"
                var parameter = Expression.Parameter(contextType, "context");
                var propertyBody = Expression.PropertyOrField(parameter, propertyInfo.Name);
                var dbSetExpression = Expression.Lambda<Func<T, object>>(propertyBody, parameter);
                var mockDbSetMethod = typeof(EfMoqTools).GetMethod("MockDbSet").MakeGenericMethod(dbSetGenericType);
                mockedContext.Setup(dbSetExpression).Returns(mockDbSetMethod.Invoke(null, new[] { listForFakeTable }));

                // Mocken der context.Set<"Property">
                var paramSetMethod = Expression.Parameter(contextType, "context");
                var setMethodInfo = typeof(T).GetMethods()
                    .First(method => method.Name == "Set" && method.ContainsGenericParameters)
                    .MakeGenericMethod(dbSetGenericType);
                var setMethodBody = Expression.Call(paramSetMethod, setMethodInfo);
                var setMethodExpression = Expression.Lambda<Func<T, object>>(setMethodBody, paramSetMethod);
                mockedContext.Setup(setMethodExpression).Returns(mockDbSetMethod.Invoke(null, new[] { listForFakeTable }));

                mockedContext.Tables.Add(propertyInfo.Name, listForFakeTable);
            }
        }

        public static DbSet<T> MockDbSet<T>(List<T> table)
            where T : class
        {
            var dbSet = new Mock<DbSet<T>>();

            dbSet.As<IQueryable<T>>().Setup(q => q.Provider).Returns(() => table.AsQueryable().Provider);
            dbSet.As<IQueryable<T>>().Setup(q => q.Expression).Returns(() => table.AsQueryable().Expression);
            dbSet.As<IQueryable<T>>().Setup(q => q.ElementType).Returns(() => table.AsQueryable().ElementType);
            dbSet.As<IQueryable<T>>().Setup(q => q.GetEnumerator()).Returns(() => table.AsQueryable().GetEnumerator());

            dbSet.Setup(set => set.Add(It.IsAny<T>())).Callback<T>(table.Add);
            dbSet.Setup(set => set.AddRange(It.IsAny<IEnumerable<T>>())).Callback<IEnumerable<T>>(table.AddRange);
            dbSet.Setup(set => set.Remove(It.IsAny<T>())).Callback<T>(t => table.Remove(t));
            dbSet.Setup(set => set.RemoveRange(It.IsAny<IEnumerable<T>>())).Callback<IEnumerable<T>>(ts => { foreach (var t in ts) { table.Remove(t); } });

            dbSet.Setup(set => set.AsNoTracking()).Returns(dbSet.Object);

            return dbSet.Object;
        }
    }
}
