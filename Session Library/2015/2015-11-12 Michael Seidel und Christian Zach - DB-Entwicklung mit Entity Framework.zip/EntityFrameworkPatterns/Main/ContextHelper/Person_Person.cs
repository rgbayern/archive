// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // Person
    [DataContract]
    public partial class Person_Person
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key for Person records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string PersonType { get; set; } // PersonType. Primary type of person: SC = Store Contact, IN = Individual (retail) customer, SP = Sales person, EM = Employee (non-sales), VC = Vendor contact, GC = General contact

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public bool NameStyle { get; set; } // NameStyle. 0 = The data in FirstName and LastName are stored in western style (first name, last name) order.  1 = Eastern style (last name, first name) order.

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Title { get; set; } // Title. A courtesy title. For example, Mr. or Ms.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string FirstName { get; set; } // FirstName. First name of the person.

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string MiddleName { get; set; } // MiddleName. Middle name or middle initial of the person.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string LastName { get; set; } // LastName. Last name of the person.

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Suffix { get; set; } // Suffix. Surname suffix. For example, Sr. or Jr.

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int EmailPromotion { get; set; } // EmailPromotion. 0 = Contact does not wish to receive e-mail promotions, 1 = Contact does wish to receive e-mail promotions from AdventureWorks, 2 = Contact does wish to receive e-mail promotions from AdventureWorks and selected partners.

        [DataMember(Order = 10, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string AdditionalContactInfo { get; set; } // AdditionalContactInfo. Additional contact information about the person stored in xml format.

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Demographics { get; set; } // Demographics. Personal information such as hobbies, and income collected from online shoppers. Used for sales analysis.

        [DataMember(Order = 12, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 13, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual HumanResources_Employee HumanResources_Employee { get; set; } // Employee.FK_Employee_Person_BusinessEntityID
        public virtual ICollection<Person_BusinessEntityContact> Person_BusinessEntityContact { get; set; } // Many to many mapping
        public virtual ICollection<Person_EmailAddress> Person_EmailAddress { get; set; } // Many to many mapping
        public virtual ICollection<Person_PersonPhone> Person_PersonPhone { get; set; } // Many to many mapping
        public virtual ICollection<Sales_Customer> Sales_Customer { get; set; } // Customer.FK_Customer_Person_PersonID
        public virtual ICollection<Sales_PersonCreditCard> Sales_PersonCreditCard { get; set; } // Many to many mapping
        public virtual Person_Password Person_Password { get; set; } // Password.FK_Password_Person_BusinessEntityID

        // Foreign keys
        public virtual Person_BusinessEntity Person_BusinessEntity { get; set; } // FK_Person_BusinessEntity_BusinessEntityID
        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Person_Person()
        {
            NameStyle = false;
            EmailPromotion = 0;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Person_BusinessEntityContact = new List<Person_BusinessEntityContact>();
            Sales_Customer = new List<Sales_Customer>();
            Person_EmailAddress = new List<Person_EmailAddress>();
            Sales_PersonCreditCard = new List<Sales_PersonCreditCard>();
            Person_PersonPhone = new List<Person_PersonPhone>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
