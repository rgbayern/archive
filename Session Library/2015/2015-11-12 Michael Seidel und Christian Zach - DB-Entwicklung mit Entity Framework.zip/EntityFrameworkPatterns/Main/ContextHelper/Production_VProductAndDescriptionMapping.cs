// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // vProductAndDescription
    internal partial class Production_VProductAndDescriptionMapping : EntityTypeConfiguration<Production_VProductAndDescription>
    {
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Production_VProductAndDescriptionMapping(string schema = "Production")
        {
            ToTable(schema + ".vProductAndDescription");
            HasKey(x => new { x.ProductId, x.Name, x.ProductModel, x.CultureId, x.Description });

            Property(x => x.ProductId).HasColumnName("ProductID").IsRequired();
            Property(x => x.Name).HasColumnName("Name").IsRequired().HasMaxLength(50);
            Property(x => x.ProductModel).HasColumnName("ProductModel").IsRequired().HasMaxLength(50);
            Property(x => x.CultureId).HasColumnName("CultureID").IsRequired().IsFixedLength().HasMaxLength(6);
            Property(x => x.Description).HasColumnName("Description").IsRequired().HasMaxLength(400);
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
