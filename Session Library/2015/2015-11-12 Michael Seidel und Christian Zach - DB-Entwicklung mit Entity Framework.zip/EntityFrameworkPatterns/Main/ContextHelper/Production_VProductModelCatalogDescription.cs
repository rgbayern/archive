// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // vProductModelCatalogDescription
    [DataContract]
    public partial class Production_VProductModelCatalogDescription
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductModelId { get; set; } // ProductModelID

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Name { get; set; } // Name

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Summary { get; set; } // Summary

        [DataMember(Order = 4, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Manufacturer { get; set; } // Manufacturer

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Copyright { get; set; } // Copyright

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ProductUrl { get; set; } // ProductURL

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string WarrantyPeriod { get; set; } // WarrantyPeriod

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string WarrantyDescription { get; set; } // WarrantyDescription

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string NoOfYears { get; set; } // NoOfYears

        [DataMember(Order = 10, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string MaintenanceDescription { get; set; } // MaintenanceDescription

        [DataMember(Order = 11, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Wheel { get; set; } // Wheel

        [DataMember(Order = 12, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Saddle { get; set; } // Saddle

        [DataMember(Order = 13, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Pedal { get; set; } // Pedal

        [DataMember(Order = 14, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string BikeFrame { get; set; } // BikeFrame

        [DataMember(Order = 15, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Crankset { get; set; } // Crankset

        [DataMember(Order = 16, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string PictureAngle { get; set; } // PictureAngle

        [DataMember(Order = 17, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string PictureSize { get; set; } // PictureSize

        [DataMember(Order = 18, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ProductPhotoId { get; set; } // ProductPhotoID

        [DataMember(Order = 19, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Material { get; set; } // Material

        [DataMember(Order = 20, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Color { get; set; } // Color

        [DataMember(Order = 21, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ProductLine { get; set; } // ProductLine

        [DataMember(Order = 22, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string Style { get; set; } // Style

        [DataMember(Order = 23, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string RiderExperience { get; set; } // RiderExperience

        [DataMember(Order = 24, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid

        [DataMember(Order = 25, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate

    }

}
