// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // CurrencyRate
    [DataContract]
    public partial class Sales_CurrencyRate
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int CurrencyRateId { get; set; } // CurrencyRateID (Primary key). Primary key for CurrencyRate records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime CurrencyRateDate { get; set; } // CurrencyRateDate. Date and time the exchange rate was obtained.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string FromCurrencyCode { get; set; } // FromCurrencyCode. Exchange rate was converted from this currency code.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ToCurrencyCode { get; set; } // ToCurrencyCode. Exchange rate was converted to this currency code.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal AverageRate { get; set; } // AverageRate. Average exchange rate for the day.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal EndOfDayRate { get; set; } // EndOfDayRate. Final exchange rate for the day.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; } // SalesOrderHeader.FK_SalesOrderHeader_CurrencyRate_CurrencyRateID

        // Foreign keys
        public virtual Sales_Currency Sales_Currency_FromCurrencyCode { get; set; } // FK_CurrencyRate_Currency_FromCurrencyCode
        public virtual Sales_Currency Sales_Currency_ToCurrencyCode { get; set; } // FK_CurrencyRate_Currency_ToCurrencyCode
        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_CurrencyRate()
        {
            ModifiedDate = System.DateTime.Now;
            Sales_SalesOrderHeader = new List<Sales_SalesOrderHeader>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
