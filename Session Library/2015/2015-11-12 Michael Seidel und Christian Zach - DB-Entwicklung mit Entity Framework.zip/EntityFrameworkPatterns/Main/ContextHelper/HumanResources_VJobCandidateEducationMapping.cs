// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // vJobCandidateEducation
    internal partial class HumanResources_VJobCandidateEducationMapping : EntityTypeConfiguration<HumanResources_VJobCandidateEducation>
    {
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public HumanResources_VJobCandidateEducationMapping(string schema = "HumanResources")
        {
            ToTable(schema + ".vJobCandidateEducation");
            HasKey(x => x.JobCandidateId);

            Property(x => x.JobCandidateId).HasColumnName("JobCandidateID").IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(x => x.Edu46Level).HasColumnName("Edu.Level").IsOptional();
            Property(x => x.Edu46StartDate).HasColumnName("Edu.StartDate").IsOptional();
            Property(x => x.Edu46EndDate).HasColumnName("Edu.EndDate").IsOptional();
            Property(x => x.Edu46Degree).HasColumnName("Edu.Degree").IsOptional().HasMaxLength(50);
            Property(x => x.Edu46Major).HasColumnName("Edu.Major").IsOptional().HasMaxLength(50);
            Property(x => x.Edu46Minor).HasColumnName("Edu.Minor").IsOptional().HasMaxLength(50);
            Property(x => x.Edu46Gpa).HasColumnName("Edu.GPA").IsOptional().HasMaxLength(5);
            Property(x => x.Edu46GpaScale).HasColumnName("Edu.GPAScale").IsOptional().HasMaxLength(5);
            Property(x => x.Edu46School).HasColumnName("Edu.School").IsOptional().HasMaxLength(100);
            Property(x => x.Edu46Loc46CountryRegion).HasColumnName("Edu.Loc.CountryRegion").IsOptional().HasMaxLength(100);
            Property(x => x.Edu46Loc46State).HasColumnName("Edu.Loc.State").IsOptional().HasMaxLength(100);
            Property(x => x.Edu46Loc46City).HasColumnName("Edu.Loc.City").IsOptional().HasMaxLength(100);
            InitializePartial();
        }
        partial void InitializePartial();
    }

}
