// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // ErrorLog
    [DataContract]
    public partial class ErrorLog
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ErrorLogId { get; set; } // ErrorLogID (Primary key). Primary key for ErrorLog records.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ErrorTime { get; set; } // ErrorTime. The date and time at which the error occurred.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string UserName { get; set; } // UserName. The user who executed the batch in which the error occurred.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ErrorNumber { get; set; } // ErrorNumber. The error number of the error that occurred.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? ErrorSeverity { get; set; } // ErrorSeverity. The severity of the error that occurred.

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? ErrorState { get; set; } // ErrorState. The state number of the error that occurred.

        [DataMember(Order = 7, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ErrorProcedure { get; set; } // ErrorProcedure. The name of the stored procedure or trigger where the error occurred.

        [DataMember(Order = 8, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? ErrorLine { get; set; } // ErrorLine. The line number at which the error occurred.

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string ErrorMessage { get; set; } // ErrorMessage. The message text of the error that occurred.

        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public ErrorLog()
        {
            ErrorTime = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
