// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // SalesPerson
    [DataContract]
    public partial class Sales_SalesPerson
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key for SalesPerson records. Foreign key to Employee.BusinessEntityID

        [DataMember(Order = 2, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? TerritoryId { get; set; } // TerritoryID. Territory currently assigned to. Foreign key to SalesTerritory.SalesTerritoryID.

        [DataMember(Order = 3, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal? SalesQuota { get; set; } // SalesQuota. Projected yearly sales.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal Bonus { get; set; } // Bonus. Bonus due if quota is met.

        [DataMember(Order = 5, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal CommissionPct { get; set; } // CommissionPct. Commision percent received per sale.

        [DataMember(Order = 6, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal SalesYtd { get; set; } // SalesYTD. Sales total year to date.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal SalesLastYear { get; set; } // SalesLastYear. Sales total of previous year.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Guid Rowguid { get; set; } // rowguid. ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.

        [DataMember(Order = 9, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Reverse navigation
        public virtual ICollection<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; } // SalesOrderHeader.FK_SalesOrderHeader_SalesPerson_SalesPersonID
        public virtual ICollection<Sales_SalesPersonQuotaHistory> Sales_SalesPersonQuotaHistory { get; set; } // Many to many mapping
        public virtual ICollection<Sales_SalesTerritoryHistory> Sales_SalesTerritoryHistory { get; set; } // Many to many mapping
        public virtual ICollection<Sales_Store> Sales_Store { get; set; } // Store.FK_Store_SalesPerson_SalesPersonID

        // Foreign keys
        public virtual HumanResources_Employee HumanResources_Employee { get; set; } // FK_SalesPerson_Employee_BusinessEntityID
        public virtual Sales_SalesTerritory Sales_SalesTerritory { get; set; } // FK_SalesPerson_SalesTerritory_TerritoryID
        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Sales_SalesPerson()
        {
            Bonus = 0.00m;
            CommissionPct = 0.00m;
            SalesYtd = 0.00m;
            SalesLastYear = 0.00m;
            Rowguid = System.Guid.NewGuid();
            ModifiedDate = System.DateTime.Now;
            Sales_SalesOrderHeader = new List<Sales_SalesOrderHeader>();
            Sales_SalesPersonQuotaHistory = new List<Sales_SalesPersonQuotaHistory>();
            Sales_SalesTerritoryHistory = new List<Sales_SalesTerritoryHistory>();
            Sales_Store = new List<Sales_Store>();
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
