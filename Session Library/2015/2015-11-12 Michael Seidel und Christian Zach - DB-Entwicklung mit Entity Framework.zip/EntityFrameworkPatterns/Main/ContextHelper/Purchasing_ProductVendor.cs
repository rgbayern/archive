// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    // ProductVendor
    [DataContract]
    public partial class Purchasing_ProductVendor
    {
        [DataMember(Order = 1, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int ProductId { get; set; } // ProductID (Primary key). Primary key. Foreign key to Product.ProductID.

        [DataMember(Order = 2, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int BusinessEntityId { get; set; } // BusinessEntityID (Primary key). Primary key. Foreign key to Vendor.BusinessEntityID.

        [DataMember(Order = 3, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int AverageLeadTime { get; set; } // AverageLeadTime. The average span of time (in days) between placing an order with the vendor and receiving the purchased product.

        [DataMember(Order = 4, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal StandardPrice { get; set; } // StandardPrice. The vendor's usual selling price.

        [DataMember(Order = 5, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public decimal? LastReceiptCost { get; set; } // LastReceiptCost. The selling price when last purchased.

        [DataMember(Order = 6, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime? LastReceiptDate { get; set; } // LastReceiptDate. Date the product was last received by the vendor.

        [DataMember(Order = 7, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int MinOrderQty { get; set; } // MinOrderQty. The maximum quantity that should be ordered.

        [DataMember(Order = 8, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int MaxOrderQty { get; set; } // MaxOrderQty. The minimum quantity that should be ordered.

        [DataMember(Order = 9, IsRequired = false)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int? OnOrderQty { get; set; } // OnOrderQty. The quantity currently on order.

        [DataMember(Order = 10, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public string UnitMeasureCode { get; set; } // UnitMeasureCode. The product's unit of measure.

        [DataMember(Order = 11, IsRequired = true)]

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public DateTime ModifiedDate { get; set; } // ModifiedDate. Date and time the record was last updated.


        // Foreign keys
        public virtual Production_Product Production_Product { get; set; } // FK_ProductVendor_Product_ProductID
        public virtual Production_UnitMeasure Production_UnitMeasure { get; set; } // FK_ProductVendor_UnitMeasure_UnitMeasureCode
        public virtual Purchasing_Vendor Purchasing_Vendor { get; set; } // FK_ProductVendor_Vendor_BusinessEntityID
        
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public Purchasing_ProductVendor()
        {
            ModifiedDate = System.DateTime.Now;
            InitializePartial();
        }

        partial void InitializePartial();
    }

}
