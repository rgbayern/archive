// ReSharper disable RedundantUsingDirective
// ReSharper disable DoNotCallOverridableMethodsInConstructor
// ReSharper disable InconsistentNaming
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable PartialMethodWithSinglePart
// ReSharper disable RedundantNameQualifier
// TargetFrameworkVersion = 4.5
#pragma warning disable 1591    //  Ignore "Missing XML Comment" warning

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.ModelConfiguration;
using System.Runtime.Serialization;
using DatabaseGeneratedOption = System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption;
using System.Data.Entity.Migrations;

namespace EntityFrameworkPatterns.ContextHelper
{
    public partial class AdventureWorks2012Context : DbContext, IAdventureWorks2012Context
    {
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<AwBuildVersion> AwBuildVersions { get; set; } // AWBuildVersion

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<DatabaseLog> DatabaseLogs { get; set; } // DatabaseLog

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<ErrorLog> ErrorLogs { get; set; } // ErrorLog

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_Department> HumanResources_Department { get; set; } // Department

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_Employee> HumanResources_Employee { get; set; } // Employee

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_EmployeeDepartmentHistory> HumanResources_EmployeeDepartmentHistory { get; set; } // EmployeeDepartmentHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_EmployeePayHistory> HumanResources_EmployeePayHistory { get; set; } // EmployeePayHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_JobCandidate> HumanResources_JobCandidate { get; set; } // JobCandidate

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_Shift> HumanResources_Shift { get; set; } // Shift

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VEmployee> HumanResources_VEmployee { get; set; } // vEmployee

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VEmployeeDepartment> HumanResources_VEmployeeDepartment { get; set; } // vEmployeeDepartment

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VEmployeeDepartmentHistory> HumanResources_VEmployeeDepartmentHistory { get; set; } // vEmployeeDepartmentHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VJobCandidate> HumanResources_VJobCandidate { get; set; } // vJobCandidate

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VJobCandidateEducation> HumanResources_VJobCandidateEducation { get; set; } // vJobCandidateEducation

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<HumanResources_VJobCandidateEmployment> HumanResources_VJobCandidateEmployment { get; set; } // vJobCandidateEmployment

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_Address> Person_Address { get; set; } // Address

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_AddressType> Person_AddressType { get; set; } // AddressType

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_BusinessEntity> Person_BusinessEntity { get; set; } // BusinessEntity

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_BusinessEntityAddress> Person_BusinessEntityAddress { get; set; } // BusinessEntityAddress

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_BusinessEntityContact> Person_BusinessEntityContact { get; set; } // BusinessEntityContact

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_ContactType> Person_ContactType { get; set; } // ContactType

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_CountryRegion> Person_CountryRegion { get; set; } // CountryRegion

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_EmailAddress> Person_EmailAddress { get; set; } // EmailAddress

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_Password> Person_Password { get; set; } // Password

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_Person> Person_Person { get; set; } // Person

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_PersonPhone> Person_PersonPhone { get; set; } // PersonPhone

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_PhoneNumberType> Person_PhoneNumberType { get; set; } // PhoneNumberType

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_StateProvince> Person_StateProvince { get; set; } // StateProvince

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_VAdditionalContactInfo> Person_VAdditionalContactInfo { get; set; } // vAdditionalContactInfo

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Person_VStateProvinceCountryRegion> Person_VStateProvinceCountryRegion { get; set; } // vStateProvinceCountryRegion

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_BillOfMaterial> Production_BillOfMaterial { get; set; } // BillOfMaterials

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_Culture> Production_Culture { get; set; } // Culture

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_Document> Production_Document { get; set; } // Document

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_Illustration> Production_Illustration { get; set; } // Illustration

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_Location> Production_Location { get; set; } // Location

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_Product> Production_Product { get; set; } // Product

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductCategory> Production_ProductCategory { get; set; } // ProductCategory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductCostHistory> Production_ProductCostHistory { get; set; } // ProductCostHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductDescription> Production_ProductDescription { get; set; } // ProductDescription

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductDocument> Production_ProductDocument { get; set; } // ProductDocument

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductInventory> Production_ProductInventory { get; set; } // ProductInventory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductListPriceHistory> Production_ProductListPriceHistory { get; set; } // ProductListPriceHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductModel> Production_ProductModel { get; set; } // ProductModel

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductModelIllustration> Production_ProductModelIllustration { get; set; } // ProductModelIllustration

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductModelProductDescriptionCulture> Production_ProductModelProductDescriptionCulture { get; set; } // ProductModelProductDescriptionCulture

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductPhoto> Production_ProductPhoto { get; set; } // ProductPhoto

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductProductPhoto> Production_ProductProductPhoto { get; set; } // ProductProductPhoto

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductReview> Production_ProductReview { get; set; } // ProductReview

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ProductSubcategory> Production_ProductSubcategory { get; set; } // ProductSubcategory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_ScrapReason> Production_ScrapReason { get; set; } // ScrapReason

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_TransactionHistory> Production_TransactionHistory { get; set; } // TransactionHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_TransactionHistoryArchive> Production_TransactionHistoryArchive { get; set; } // TransactionHistoryArchive

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_UnitMeasure> Production_UnitMeasure { get; set; } // UnitMeasure

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_VProductAndDescription> Production_VProductAndDescription { get; set; } // vProductAndDescription

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_VProductModelCatalogDescription> Production_VProductModelCatalogDescription { get; set; } // vProductModelCatalogDescription

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_VProductModelInstruction> Production_VProductModelInstruction { get; set; } // vProductModelInstructions

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_WorkOrder> Production_WorkOrder { get; set; } // WorkOrder

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Production_WorkOrderRouting> Production_WorkOrderRouting { get; set; } // WorkOrderRouting

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_ProductVendor> Purchasing_ProductVendor { get; set; } // ProductVendor

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_PurchaseOrderDetail> Purchasing_PurchaseOrderDetail { get; set; } // PurchaseOrderDetail

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_PurchaseOrderHeader> Purchasing_PurchaseOrderHeader { get; set; } // PurchaseOrderHeader

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_ShipMethod> Purchasing_ShipMethod { get; set; } // ShipMethod

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_Vendor> Purchasing_Vendor { get; set; } // Vendor

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_VVendorWithAddress> Purchasing_VVendorWithAddress { get; set; } // vVendorWithAddresses

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Purchasing_VVendorWithContact> Purchasing_VVendorWithContact { get; set; } // vVendorWithContacts

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_CountryRegionCurrency> Sales_CountryRegionCurrency { get; set; } // CountryRegionCurrency

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_CreditCard> Sales_CreditCard { get; set; } // CreditCard

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_Currency> Sales_Currency { get; set; } // Currency

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_CurrencyRate> Sales_CurrencyRate { get; set; } // CurrencyRate

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_Customer> Sales_Customer { get; set; } // Customer

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_PersonCreditCard> Sales_PersonCreditCard { get; set; } // PersonCreditCard

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesOrderDetail> Sales_SalesOrderDetail { get; set; } // SalesOrderDetail

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesOrderHeader> Sales_SalesOrderHeader { get; set; } // SalesOrderHeader

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesOrderHeaderSalesReason> Sales_SalesOrderHeaderSalesReason { get; set; } // SalesOrderHeaderSalesReason

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesPerson> Sales_SalesPerson { get; set; } // SalesPerson

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesPersonQuotaHistory> Sales_SalesPersonQuotaHistory { get; set; } // SalesPersonQuotaHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesReason> Sales_SalesReason { get; set; } // SalesReason

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesTaxRate> Sales_SalesTaxRate { get; set; } // SalesTaxRate

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesTerritory> Sales_SalesTerritory { get; set; } // SalesTerritory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SalesTerritoryHistory> Sales_SalesTerritoryHistory { get; set; } // SalesTerritoryHistory

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_ShoppingCartItem> Sales_ShoppingCartItem { get; set; } // ShoppingCartItem

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SpecialOffer> Sales_SpecialOffer { get; set; } // SpecialOffer

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_SpecialOfferProduct> Sales_SpecialOfferProduct { get; set; } // SpecialOfferProduct

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_Store> Sales_Store { get; set; } // Store

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VIndividualCustomer> Sales_VIndividualCustomer { get; set; } // vIndividualCustomer

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VPersonDemographic> Sales_VPersonDemographic { get; set; } // vPersonDemographics

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VSalesPerson> Sales_VSalesPerson { get; set; } // vSalesPerson

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VSalesPersonSalesByFiscalYear> Sales_VSalesPersonSalesByFiscalYear { get; set; } // vSalesPersonSalesByFiscalYears

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VStoreWithAddress> Sales_VStoreWithAddress { get; set; } // vStoreWithAddresses

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VStoreWithContact> Sales_VStoreWithContact { get; set; } // vStoreWithContacts

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public IDbSet<Sales_VStoreWithDemographic> Sales_VStoreWithDemographic { get; set; } // vStoreWithDemographics

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        static AdventureWorks2012Context()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<AdventureWorks2012Context, MigrationConfig>());
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public AdventureWorks2012Context()
            : base("Name=AdventureWorks2012")
        {
            InitializePartial();
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public AdventureWorks2012Context(string connectionString) : base(connectionString)
        {
            InitializePartial();
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public AdventureWorks2012Context(string connectionString, System.Data.Entity.Infrastructure.DbCompiledModel model) : base(connectionString, model)
        {
            InitializePartial();
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new AwBuildVersionMapping());
            modelBuilder.Configurations.Add(new DatabaseLogMapping());
            modelBuilder.Configurations.Add(new ErrorLogMapping());
            modelBuilder.Configurations.Add(new HumanResources_DepartmentMapping());
            modelBuilder.Configurations.Add(new HumanResources_EmployeeMapping());
            modelBuilder.Configurations.Add(new HumanResources_EmployeeDepartmentHistoryMapping());
            modelBuilder.Configurations.Add(new HumanResources_EmployeePayHistoryMapping());
            modelBuilder.Configurations.Add(new HumanResources_JobCandidateMapping());
            modelBuilder.Configurations.Add(new HumanResources_ShiftMapping());
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeMapping());
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeDepartmentMapping());
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeDepartmentHistoryMapping());
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateMapping());
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateEducationMapping());
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateEmploymentMapping());
            modelBuilder.Configurations.Add(new Person_AddressMapping());
            modelBuilder.Configurations.Add(new Person_AddressTypeMapping());
            modelBuilder.Configurations.Add(new Person_BusinessEntityMapping());
            modelBuilder.Configurations.Add(new Person_BusinessEntityAddressMapping());
            modelBuilder.Configurations.Add(new Person_BusinessEntityContactMapping());
            modelBuilder.Configurations.Add(new Person_ContactTypeMapping());
            modelBuilder.Configurations.Add(new Person_CountryRegionMapping());
            modelBuilder.Configurations.Add(new Person_EmailAddressMapping());
            modelBuilder.Configurations.Add(new Person_PasswordMapping());
            modelBuilder.Configurations.Add(new Person_PersonMapping());
            modelBuilder.Configurations.Add(new Person_PersonPhoneMapping());
            modelBuilder.Configurations.Add(new Person_PhoneNumberTypeMapping());
            modelBuilder.Configurations.Add(new Person_StateProvinceMapping());
            modelBuilder.Configurations.Add(new Person_VAdditionalContactInfoMapping());
            modelBuilder.Configurations.Add(new Person_VStateProvinceCountryRegionMapping());
            modelBuilder.Configurations.Add(new Production_BillOfMaterialMapping());
            modelBuilder.Configurations.Add(new Production_CultureMapping());
            modelBuilder.Configurations.Add(new Production_DocumentMapping());
            modelBuilder.Configurations.Add(new Production_IllustrationMapping());
            modelBuilder.Configurations.Add(new Production_LocationMapping());
            modelBuilder.Configurations.Add(new Production_ProductMapping());
            modelBuilder.Configurations.Add(new Production_ProductCategoryMapping());
            modelBuilder.Configurations.Add(new Production_ProductCostHistoryMapping());
            modelBuilder.Configurations.Add(new Production_ProductDescriptionMapping());
            modelBuilder.Configurations.Add(new Production_ProductDocumentMapping());
            modelBuilder.Configurations.Add(new Production_ProductInventoryMapping());
            modelBuilder.Configurations.Add(new Production_ProductListPriceHistoryMapping());
            modelBuilder.Configurations.Add(new Production_ProductModelMapping());
            modelBuilder.Configurations.Add(new Production_ProductModelIllustrationMapping());
            modelBuilder.Configurations.Add(new Production_ProductModelProductDescriptionCultureMapping());
            modelBuilder.Configurations.Add(new Production_ProductPhotoMapping());
            modelBuilder.Configurations.Add(new Production_ProductProductPhotoMapping());
            modelBuilder.Configurations.Add(new Production_ProductReviewMapping());
            modelBuilder.Configurations.Add(new Production_ProductSubcategoryMapping());
            modelBuilder.Configurations.Add(new Production_ScrapReasonMapping());
            modelBuilder.Configurations.Add(new Production_TransactionHistoryMapping());
            modelBuilder.Configurations.Add(new Production_TransactionHistoryArchiveMapping());
            modelBuilder.Configurations.Add(new Production_UnitMeasureMapping());
            modelBuilder.Configurations.Add(new Production_VProductAndDescriptionMapping());
            modelBuilder.Configurations.Add(new Production_VProductModelCatalogDescriptionMapping());
            modelBuilder.Configurations.Add(new Production_VProductModelInstructionMapping());
            modelBuilder.Configurations.Add(new Production_WorkOrderMapping());
            modelBuilder.Configurations.Add(new Production_WorkOrderRoutingMapping());
            modelBuilder.Configurations.Add(new Purchasing_ProductVendorMapping());
            modelBuilder.Configurations.Add(new Purchasing_PurchaseOrderDetailMapping());
            modelBuilder.Configurations.Add(new Purchasing_PurchaseOrderHeaderMapping());
            modelBuilder.Configurations.Add(new Purchasing_ShipMethodMapping());
            modelBuilder.Configurations.Add(new Purchasing_VendorMapping());
            modelBuilder.Configurations.Add(new Purchasing_VVendorWithAddressMapping());
            modelBuilder.Configurations.Add(new Purchasing_VVendorWithContactMapping());
            modelBuilder.Configurations.Add(new Sales_CountryRegionCurrencyMapping());
            modelBuilder.Configurations.Add(new Sales_CreditCardMapping());
            modelBuilder.Configurations.Add(new Sales_CurrencyMapping());
            modelBuilder.Configurations.Add(new Sales_CurrencyRateMapping());
            modelBuilder.Configurations.Add(new Sales_CustomerMapping());
            modelBuilder.Configurations.Add(new Sales_PersonCreditCardMapping());
            modelBuilder.Configurations.Add(new Sales_SalesOrderDetailMapping());
            modelBuilder.Configurations.Add(new Sales_SalesOrderHeaderMapping());
            modelBuilder.Configurations.Add(new Sales_SalesOrderHeaderSalesReasonMapping());
            modelBuilder.Configurations.Add(new Sales_SalesPersonMapping());
            modelBuilder.Configurations.Add(new Sales_SalesPersonQuotaHistoryMapping());
            modelBuilder.Configurations.Add(new Sales_SalesReasonMapping());
            modelBuilder.Configurations.Add(new Sales_SalesTaxRateMapping());
            modelBuilder.Configurations.Add(new Sales_SalesTerritoryMapping());
            modelBuilder.Configurations.Add(new Sales_SalesTerritoryHistoryMapping());
            modelBuilder.Configurations.Add(new Sales_ShoppingCartItemMapping());
            modelBuilder.Configurations.Add(new Sales_SpecialOfferMapping());
            modelBuilder.Configurations.Add(new Sales_SpecialOfferProductMapping());
            modelBuilder.Configurations.Add(new Sales_StoreMapping());
            modelBuilder.Configurations.Add(new Sales_VIndividualCustomerMapping());
            modelBuilder.Configurations.Add(new Sales_VPersonDemographicMapping());
            modelBuilder.Configurations.Add(new Sales_VSalesPersonMapping());
            modelBuilder.Configurations.Add(new Sales_VSalesPersonSalesByFiscalYearMapping());
            modelBuilder.Configurations.Add(new Sales_VStoreWithAddressMapping());
            modelBuilder.Configurations.Add(new Sales_VStoreWithContactMapping());
            modelBuilder.Configurations.Add(new Sales_VStoreWithDemographicMapping());

            OnModelCreatingPartial(modelBuilder);
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public static DbModelBuilder CreateModel(DbModelBuilder modelBuilder, string schema)
        {
            modelBuilder.Configurations.Add(new AwBuildVersionMapping(schema));
            modelBuilder.Configurations.Add(new DatabaseLogMapping(schema));
            modelBuilder.Configurations.Add(new ErrorLogMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_DepartmentMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_EmployeeMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_EmployeeDepartmentHistoryMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_EmployeePayHistoryMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_JobCandidateMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_ShiftMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeDepartmentMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VEmployeeDepartmentHistoryMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateEducationMapping(schema));
            modelBuilder.Configurations.Add(new HumanResources_VJobCandidateEmploymentMapping(schema));
            modelBuilder.Configurations.Add(new Person_AddressMapping(schema));
            modelBuilder.Configurations.Add(new Person_AddressTypeMapping(schema));
            modelBuilder.Configurations.Add(new Person_BusinessEntityMapping(schema));
            modelBuilder.Configurations.Add(new Person_BusinessEntityAddressMapping(schema));
            modelBuilder.Configurations.Add(new Person_BusinessEntityContactMapping(schema));
            modelBuilder.Configurations.Add(new Person_ContactTypeMapping(schema));
            modelBuilder.Configurations.Add(new Person_CountryRegionMapping(schema));
            modelBuilder.Configurations.Add(new Person_EmailAddressMapping(schema));
            modelBuilder.Configurations.Add(new Person_PasswordMapping(schema));
            modelBuilder.Configurations.Add(new Person_PersonMapping(schema));
            modelBuilder.Configurations.Add(new Person_PersonPhoneMapping(schema));
            modelBuilder.Configurations.Add(new Person_PhoneNumberTypeMapping(schema));
            modelBuilder.Configurations.Add(new Person_StateProvinceMapping(schema));
            modelBuilder.Configurations.Add(new Person_VAdditionalContactInfoMapping(schema));
            modelBuilder.Configurations.Add(new Person_VStateProvinceCountryRegionMapping(schema));
            modelBuilder.Configurations.Add(new Production_BillOfMaterialMapping(schema));
            modelBuilder.Configurations.Add(new Production_CultureMapping(schema));
            modelBuilder.Configurations.Add(new Production_DocumentMapping(schema));
            modelBuilder.Configurations.Add(new Production_IllustrationMapping(schema));
            modelBuilder.Configurations.Add(new Production_LocationMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductCategoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductCostHistoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductDescriptionMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductDocumentMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductInventoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductListPriceHistoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductModelMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductModelIllustrationMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductModelProductDescriptionCultureMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductPhotoMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductProductPhotoMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductReviewMapping(schema));
            modelBuilder.Configurations.Add(new Production_ProductSubcategoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_ScrapReasonMapping(schema));
            modelBuilder.Configurations.Add(new Production_TransactionHistoryMapping(schema));
            modelBuilder.Configurations.Add(new Production_TransactionHistoryArchiveMapping(schema));
            modelBuilder.Configurations.Add(new Production_UnitMeasureMapping(schema));
            modelBuilder.Configurations.Add(new Production_VProductAndDescriptionMapping(schema));
            modelBuilder.Configurations.Add(new Production_VProductModelCatalogDescriptionMapping(schema));
            modelBuilder.Configurations.Add(new Production_VProductModelInstructionMapping(schema));
            modelBuilder.Configurations.Add(new Production_WorkOrderMapping(schema));
            modelBuilder.Configurations.Add(new Production_WorkOrderRoutingMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_ProductVendorMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_PurchaseOrderDetailMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_PurchaseOrderHeaderMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_ShipMethodMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_VendorMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_VVendorWithAddressMapping(schema));
            modelBuilder.Configurations.Add(new Purchasing_VVendorWithContactMapping(schema));
            modelBuilder.Configurations.Add(new Sales_CountryRegionCurrencyMapping(schema));
            modelBuilder.Configurations.Add(new Sales_CreditCardMapping(schema));
            modelBuilder.Configurations.Add(new Sales_CurrencyMapping(schema));
            modelBuilder.Configurations.Add(new Sales_CurrencyRateMapping(schema));
            modelBuilder.Configurations.Add(new Sales_CustomerMapping(schema));
            modelBuilder.Configurations.Add(new Sales_PersonCreditCardMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesOrderDetailMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesOrderHeaderMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesOrderHeaderSalesReasonMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesPersonMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesPersonQuotaHistoryMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesReasonMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesTaxRateMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesTerritoryMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SalesTerritoryHistoryMapping(schema));
            modelBuilder.Configurations.Add(new Sales_ShoppingCartItemMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SpecialOfferMapping(schema));
            modelBuilder.Configurations.Add(new Sales_SpecialOfferProductMapping(schema));
            modelBuilder.Configurations.Add(new Sales_StoreMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VIndividualCustomerMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VPersonDemographicMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VSalesPersonMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VSalesPersonSalesByFiscalYearMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VStoreWithAddressMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VStoreWithContactMapping(schema));
            modelBuilder.Configurations.Add(new Sales_VStoreWithDemographicMapping(schema));
            return modelBuilder;
        }

        partial void InitializePartial();
        partial void OnModelCreatingPartial(DbModelBuilder modelBuilder);
        
        // Stored Procedures
        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public List<UspGetBillOfMaterialsReturnModel> UspGetBillOfMaterials(int startProductId, DateTime checkDate, out int procResult)
        {
            var startProductIdParam = new SqlParameter { ParameterName = "@StartProductID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = startProductId };
            var checkDateParam = new SqlParameter { ParameterName = "@CheckDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = checkDate };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            var procResultData = Database.SqlQuery<UspGetBillOfMaterialsReturnModel>("EXEC @procResult = uspGetBillOfMaterials @StartProductID, @CheckDate", new object[]
            {
                startProductIdParam,
                checkDateParam,
                procResultParam

            }).ToList();
 
            procResult = (int) procResultParam.Value;
            return procResultData;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public List<UspGetEmployeeManagersReturnModel> UspGetEmployeeManagers(int businessEntityId, out int procResult)
        {
            var businessEntityIdParam = new SqlParameter { ParameterName = "@BusinessEntityID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = businessEntityId };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            var procResultData = Database.SqlQuery<UspGetEmployeeManagersReturnModel>("EXEC @procResult = uspGetEmployeeManagers @BusinessEntityID", new object[]
            {
                businessEntityIdParam,
                procResultParam

            }).ToList();
 
            procResult = (int) procResultParam.Value;
            return procResultData;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public List<UspGetManagerEmployeesReturnModel> UspGetManagerEmployees(int businessEntityId, out int procResult)
        {
            var businessEntityIdParam = new SqlParameter { ParameterName = "@BusinessEntityID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = businessEntityId };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            var procResultData = Database.SqlQuery<UspGetManagerEmployeesReturnModel>("EXEC @procResult = uspGetManagerEmployees @BusinessEntityID", new object[]
            {
                businessEntityIdParam,
                procResultParam

            }).ToList();
 
            procResult = (int) procResultParam.Value;
            return procResultData;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public List<UspGetWhereUsedProductIdReturnModel> UspGetWhereUsedProductId(int startProductId, DateTime checkDate, out int procResult)
        {
            var startProductIdParam = new SqlParameter { ParameterName = "@StartProductID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = startProductId };
            var checkDateParam = new SqlParameter { ParameterName = "@CheckDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = checkDate };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            var procResultData = Database.SqlQuery<UspGetWhereUsedProductIdReturnModel>("EXEC @procResult = uspGetWhereUsedProductID @StartProductID, @CheckDate", new object[]
            {
                startProductIdParam,
                checkDateParam,
                procResultParam

            }).ToList();
 
            procResult = (int) procResultParam.Value;
            return procResultData;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int UspLogError(out int errorLogId)
        {
            var errorLogIdParam = new SqlParameter { ParameterName = "@ErrorLogID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            Database.ExecuteSqlCommand("EXEC @procResult = uspLogError @ErrorLogID OUTPUT", new object[]
            {
                errorLogIdParam,
                procResultParam
 
            });
            errorLogId = (int) errorLogIdParam.Value;
 
            return (int) procResultParam.Value;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int UspSearchCandidateResumes(string searchString, bool useInflectional, bool useThesaurus, int language)
        {
            var searchStringParam = new SqlParameter { ParameterName = "@searchString", SqlDbType = SqlDbType.NVarChar, Direction = ParameterDirection.Input, Value = searchString, Size = 1000 };
            var useInflectionalParam = new SqlParameter { ParameterName = "@useInflectional", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Input, Value = useInflectional };
            var useThesaurusParam = new SqlParameter { ParameterName = "@useThesaurus", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Input, Value = useThesaurus };
            var languageParam = new SqlParameter { ParameterName = "@language", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = language };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            Database.ExecuteSqlCommand("EXEC @procResult = uspSearchCandidateResumes @searchString, @useInflectional, @useThesaurus, @language", new object[]
            {
                searchStringParam,
                useInflectionalParam,
                useThesaurusParam,
                languageParam,
                procResultParam
 
            });
 
            return (int) procResultParam.Value;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int HumanResources_HumanResources_UspUpdateEmployeeHireInfo(int businessEntityId, string jobTitle, DateTime hireDate, DateTime rateChangeDate, decimal rate, byte payFrequency, bool currentFlag)
        {
            var businessEntityIdParam = new SqlParameter { ParameterName = "@BusinessEntityID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = businessEntityId };
            var jobTitleParam = new SqlParameter { ParameterName = "@JobTitle", SqlDbType = SqlDbType.NVarChar, Direction = ParameterDirection.Input, Value = jobTitle, Size = 50 };
            var hireDateParam = new SqlParameter { ParameterName = "@HireDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = hireDate };
            var rateChangeDateParam = new SqlParameter { ParameterName = "@RateChangeDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = rateChangeDate };
            var rateParam = new SqlParameter { ParameterName = "@Rate", SqlDbType = SqlDbType.Money, Direction = ParameterDirection.Input, Value = rate };
            var payFrequencyParam = new SqlParameter { ParameterName = "@PayFrequency", SqlDbType = SqlDbType.TinyInt, Direction = ParameterDirection.Input, Value = payFrequency };
            var currentFlagParam = new SqlParameter { ParameterName = "@CurrentFlag", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Input, Value = currentFlag };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            Database.ExecuteSqlCommand("EXEC @procResult = uspUpdateEmployeeHireInfo @BusinessEntityID, @JobTitle, @HireDate, @RateChangeDate, @Rate, @PayFrequency, @CurrentFlag", new object[]
            {
                businessEntityIdParam,
                jobTitleParam,
                hireDateParam,
                rateChangeDateParam,
                rateParam,
                payFrequencyParam,
                currentFlagParam,
                procResultParam
 
            });
 
            return (int) procResultParam.Value;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int HumanResources_HumanResources_UspUpdateEmployeeLogin(int businessEntityId, string organizationNode, string loginId, string jobTitle, DateTime hireDate, bool currentFlag)
        {
            var businessEntityIdParam = new SqlParameter { ParameterName = "@BusinessEntityID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = businessEntityId };
            var organizationNodeParam = new SqlParameter { ParameterName = "@OrganizationNode", SqlDbType = SqlDbType.VarChar, Direction = ParameterDirection.Input, Value = organizationNode, Size = 892 };
            var loginIdParam = new SqlParameter { ParameterName = "@LoginID", SqlDbType = SqlDbType.NVarChar, Direction = ParameterDirection.Input, Value = loginId, Size = 256 };
            var jobTitleParam = new SqlParameter { ParameterName = "@JobTitle", SqlDbType = SqlDbType.NVarChar, Direction = ParameterDirection.Input, Value = jobTitle, Size = 50 };
            var hireDateParam = new SqlParameter { ParameterName = "@HireDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = hireDate };
            var currentFlagParam = new SqlParameter { ParameterName = "@CurrentFlag", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Input, Value = currentFlag };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            Database.ExecuteSqlCommand("EXEC @procResult = uspUpdateEmployeeLogin @BusinessEntityID, @OrganizationNode, @LoginID, @JobTitle, @HireDate, @CurrentFlag", new object[]
            {
                businessEntityIdParam,
                organizationNodeParam,
                loginIdParam,
                jobTitleParam,
                hireDateParam,
                currentFlagParam,
                procResultParam
 
            });
 
            return (int) procResultParam.Value;
        }

        [GeneratedCodeAttribute("EF.Reverse.POCO.Generator", "1.0.0.0")]
        public int HumanResources_HumanResources_UspUpdateEmployeePersonalInfo(int businessEntityId, string nationalIdNumber, DateTime birthDate, string maritalStatus, string gender)
        {
            var businessEntityIdParam = new SqlParameter { ParameterName = "@BusinessEntityID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Input, Value = businessEntityId };
            var nationalIdNumberParam = new SqlParameter { ParameterName = "@NationalIDNumber", SqlDbType = SqlDbType.NVarChar, Direction = ParameterDirection.Input, Value = nationalIdNumber, Size = 15 };
            var birthDateParam = new SqlParameter { ParameterName = "@BirthDate", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Input, Value = birthDate };
            var maritalStatusParam = new SqlParameter { ParameterName = "@MaritalStatus", SqlDbType = SqlDbType.NChar, Direction = ParameterDirection.Input, Value = maritalStatus, Size = 1 };
            var genderParam = new SqlParameter { ParameterName = "@Gender", SqlDbType = SqlDbType.NChar, Direction = ParameterDirection.Input, Value = gender, Size = 1 };
            var procResultParam = new SqlParameter { ParameterName = "@procResult", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
 
            Database.ExecuteSqlCommand("EXEC @procResult = uspUpdateEmployeePersonalInfo @BusinessEntityID, @NationalIDNumber, @BirthDate, @MaritalStatus, @Gender", new object[]
            {
                businessEntityIdParam,
                nationalIdNumberParam,
                birthDateParam,
                maritalStatusParam,
                genderParam,
                procResultParam
 
            });
 
            return (int) procResultParam.Value;
        }

    }
}
